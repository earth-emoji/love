--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2 (Ubuntu 12.2-4)
-- Dumped by pg_dump version 12.2 (Ubuntu 12.2-4)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts_member; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts_member (
    id integer NOT NULL,
    slug character varying(80) NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.accounts_member OWNER TO postgres;

--
-- Name: accounts_member_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_member_id_seq OWNER TO postgres;

--
-- Name: accounts_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_member_id_seq OWNED BY public.accounts_member.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: campaigns_campaign; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campaigns_campaign (
    id integer NOT NULL,
    slug character varying(128) NOT NULL,
    title character varying(100) NOT NULL,
    description text,
    funds_needed numeric(11,2),
    funds_raised numeric(11,2),
    funds_available numeric(11,2),
    is_open boolean NOT NULL,
    is_active boolean NOT NULL,
    closing_statement text,
    volunteers_needed integer NOT NULL,
    cause_id integer NOT NULL,
    initiator_id integer NOT NULL,
    CONSTRAINT campaigns_campaign_volunteers_needed_check CHECK ((volunteers_needed >= 0))
);


ALTER TABLE public.campaigns_campaign OWNER TO postgres;

--
-- Name: campaigns_campaign_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.campaigns_campaign_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campaigns_campaign_id_seq OWNER TO postgres;

--
-- Name: campaigns_campaign_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.campaigns_campaign_id_seq OWNED BY public.campaigns_campaign.id;


--
-- Name: campaigns_cause; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campaigns_cause (
    id integer NOT NULL,
    slug character varying(80) NOT NULL,
    name character varying(60) NOT NULL,
    category character varying(15) NOT NULL
);


ALTER TABLE public.campaigns_cause OWNER TO postgres;

--
-- Name: campaigns_cause_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.campaigns_cause_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campaigns_cause_id_seq OWNER TO postgres;

--
-- Name: campaigns_cause_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.campaigns_cause_id_seq OWNED BY public.campaigns_cause.id;


--
-- Name: campaigns_cause_supporters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campaigns_cause_supporters (
    id integer NOT NULL,
    cause_id integer NOT NULL,
    member_id integer NOT NULL
);


ALTER TABLE public.campaigns_cause_supporters OWNER TO postgres;

--
-- Name: campaigns_cause_supporters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.campaigns_cause_supporters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campaigns_cause_supporters_id_seq OWNER TO postgres;

--
-- Name: campaigns_cause_supporters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.campaigns_cause_supporters_id_seq OWNED BY public.campaigns_cause_supporters.id;


--
-- Name: campaigns_volunteer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campaigns_volunteer (
    id integer NOT NULL,
    slug character varying(50) NOT NULL,
    reason text,
    status character varying(20) NOT NULL,
    campaign_id integer NOT NULL,
    member_id integer NOT NULL
);


ALTER TABLE public.campaigns_volunteer OWNER TO postgres;

--
-- Name: campaigns_volunteer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.campaigns_volunteer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campaigns_volunteer_id_seq OWNER TO postgres;

--
-- Name: campaigns_volunteer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.campaigns_volunteer_id_seq OWNED BY public.campaigns_volunteer.id;


--
-- Name: catalog_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_category (
    id integer NOT NULL,
    slug character varying(128) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    visible boolean NOT NULL,
    show_on_homepage boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    parent_id integer
);


ALTER TABLE public.catalog_category OWNER TO postgres;

--
-- Name: catalog_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_category_id_seq OWNER TO postgres;

--
-- Name: catalog_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_category_id_seq OWNED BY public.catalog_category.id;


--
-- Name: catalog_predefineattributevalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_predefineattributevalue (
    id integer NOT NULL,
    slug character varying(80) NOT NULL,
    name character varying(255) NOT NULL,
    attribute_id integer NOT NULL
);


ALTER TABLE public.catalog_predefineattributevalue OWNER TO postgres;

--
-- Name: catalog_predefineattributevalue_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_predefineattributevalue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_predefineattributevalue_id_seq OWNER TO postgres;

--
-- Name: catalog_predefineattributevalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_predefineattributevalue_id_seq OWNED BY public.catalog_predefineattributevalue.id;


--
-- Name: catalog_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_product (
    id integer NOT NULL,
    slug character varying(80) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    stock_quantity integer NOT NULL,
    low_stock boolean NOT NULL,
    out_of_stock boolean NOT NULL,
    published boolean NOT NULL,
    mark_as_new boolean NOT NULL,
    new_start timestamp with time zone,
    new_end timestamp with time zone,
    not_returnable boolean NOT NULL,
    show_on_homepage boolean NOT NULL,
    featured boolean NOT NULL,
    allow_reviews boolean NOT NULL,
    vendor_comments text,
    price numeric(11,2),
    sales_rate double precision,
    on_sale boolean NOT NULL,
    is_free boolean NOT NULL,
    call_for_price boolean NOT NULL,
    weight numeric(4,2),
    length numeric(4,2),
    width numeric(4,2),
    height numeric(4,2),
    sold integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    album_id integer,
    parent_id integer,
    vendor_id integer NOT NULL,
    CONSTRAINT catalog_product_sold_check CHECK ((sold >= 0)),
    CONSTRAINT catalog_product_stock_quantity_check CHECK ((stock_quantity >= 0))
);


ALTER TABLE public.catalog_product OWNER TO postgres;

--
-- Name: catalog_product_attributes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_product_attributes (
    id integer NOT NULL,
    product_id integer NOT NULL,
    predefineattributevalue_id integer NOT NULL
);


ALTER TABLE public.catalog_product_attributes OWNER TO postgres;

--
-- Name: catalog_product_attributes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_product_attributes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_product_attributes_id_seq OWNER TO postgres;

--
-- Name: catalog_product_attributes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_product_attributes_id_seq OWNED BY public.catalog_product_attributes.id;


--
-- Name: catalog_product_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_product_categories (
    id integer NOT NULL,
    product_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.catalog_product_categories OWNER TO postgres;

--
-- Name: catalog_product_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_product_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_product_categories_id_seq OWNER TO postgres;

--
-- Name: catalog_product_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_product_categories_id_seq OWNED BY public.catalog_product_categories.id;


--
-- Name: catalog_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_product_id_seq OWNER TO postgres;

--
-- Name: catalog_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_product_id_seq OWNED BY public.catalog_product.id;


--
-- Name: catalog_productattribute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_productattribute (
    id integer NOT NULL,
    slug character varying(80) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.catalog_productattribute OWNER TO postgres;

--
-- Name: catalog_productattribute_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_productattribute_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_productattribute_id_seq OWNER TO postgres;

--
-- Name: catalog_productattribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_productattribute_id_seq OWNED BY public.catalog_productattribute.id;


--
-- Name: catalog_productbundle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_productbundle (
    id integer NOT NULL,
    slug character varying(80) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    stock_quantity integer NOT NULL,
    low_stock boolean NOT NULL,
    out_of_stock boolean NOT NULL,
    published boolean NOT NULL,
    mark_as_new boolean NOT NULL,
    new_start timestamp with time zone,
    new_end timestamp with time zone,
    not_returnable boolean NOT NULL,
    show_on_homepage boolean NOT NULL,
    featured boolean NOT NULL,
    allow_reviews boolean NOT NULL,
    vendor_comments text,
    price numeric(11,2),
    sales_rate double precision,
    on_sale boolean NOT NULL,
    is_free boolean NOT NULL,
    call_for_price boolean NOT NULL,
    weight numeric(4,2),
    lenght numeric(4,2),
    width numeric(4,2),
    height numeric(4,2),
    sold integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    album_id integer,
    vendor_id integer NOT NULL,
    CONSTRAINT catalog_productbundle_sold_check CHECK ((sold >= 0)),
    CONSTRAINT catalog_productbundle_stock_quantity_check CHECK ((stock_quantity >= 0))
);


ALTER TABLE public.catalog_productbundle OWNER TO postgres;

--
-- Name: catalog_productbundle_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_productbundle_categories (
    id integer NOT NULL,
    productbundle_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.catalog_productbundle_categories OWNER TO postgres;

--
-- Name: catalog_productbundle_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_productbundle_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_productbundle_categories_id_seq OWNER TO postgres;

--
-- Name: catalog_productbundle_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_productbundle_categories_id_seq OWNED BY public.catalog_productbundle_categories.id;


--
-- Name: catalog_productbundle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_productbundle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_productbundle_id_seq OWNER TO postgres;

--
-- Name: catalog_productbundle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_productbundle_id_seq OWNED BY public.catalog_productbundle.id;


--
-- Name: catalog_productbundle_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_productbundle_products (
    id integer NOT NULL,
    productbundle_id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE public.catalog_productbundle_products OWNER TO postgres;

--
-- Name: catalog_productbundle_products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_productbundle_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_productbundle_products_id_seq OWNER TO postgres;

--
-- Name: catalog_productbundle_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_productbundle_products_id_seq OWNED BY public.catalog_productbundle_products.id;


--
-- Name: discussions_conversation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discussions_conversation (
    id integer NOT NULL,
    slug character varying(180) NOT NULL,
    title character varying(150) NOT NULL,
    content text NOT NULL,
    is_private boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    author_id integer NOT NULL,
    topic_id integer
);


ALTER TABLE public.discussions_conversation OWNER TO postgres;

--
-- Name: discussions_conversation_allowed_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discussions_conversation_allowed_members (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    member_id integer NOT NULL
);


ALTER TABLE public.discussions_conversation_allowed_members OWNER TO postgres;

--
-- Name: discussions_conversation_allowed_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discussions_conversation_allowed_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discussions_conversation_allowed_members_id_seq OWNER TO postgres;

--
-- Name: discussions_conversation_allowed_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discussions_conversation_allowed_members_id_seq OWNED BY public.discussions_conversation_allowed_members.id;


--
-- Name: discussions_conversation_blacklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discussions_conversation_blacklist (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    member_id integer NOT NULL
);


ALTER TABLE public.discussions_conversation_blacklist OWNER TO postgres;

--
-- Name: discussions_conversation_blacklist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discussions_conversation_blacklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discussions_conversation_blacklist_id_seq OWNER TO postgres;

--
-- Name: discussions_conversation_blacklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discussions_conversation_blacklist_id_seq OWNED BY public.discussions_conversation_blacklist.id;


--
-- Name: discussions_conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discussions_conversation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discussions_conversation_id_seq OWNER TO postgres;

--
-- Name: discussions_conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discussions_conversation_id_seq OWNED BY public.discussions_conversation.id;


--
-- Name: discussions_discussion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discussions_discussion (
    id integer NOT NULL,
    slug character varying(128) NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.discussions_discussion OWNER TO postgres;

--
-- Name: discussions_discussion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discussions_discussion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discussions_discussion_id_seq OWNER TO postgres;

--
-- Name: discussions_discussion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discussions_discussion_id_seq OWNED BY public.discussions_discussion.id;


--
-- Name: discussions_reply; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discussions_reply (
    id integer NOT NULL,
    slug character varying(50) NOT NULL,
    content text NOT NULL,
    is_published boolean NOT NULL,
    published_date timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    author_id integer NOT NULL,
    conversation_id integer NOT NULL,
    parent_id integer
);


ALTER TABLE public.discussions_reply OWNER TO postgres;

--
-- Name: discussions_reply_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discussions_reply_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discussions_reply_id_seq OWNER TO postgres;

--
-- Name: discussions_reply_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discussions_reply_id_seq OWNED BY public.discussions_reply.id;


--
-- Name: discussions_topic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discussions_topic (
    id integer NOT NULL,
    slug character varying(128) NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    campaign_id integer,
    discussion_id integer
);


ALTER TABLE public.discussions_topic OWNER TO postgres;

--
-- Name: discussions_topic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discussions_topic_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.discussions_topic_id_seq OWNER TO postgres;

--
-- Name: discussions_topic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discussions_topic_id_seq OWNED BY public.discussions_topic.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: django_summernote_attachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_summernote_attachment (
    id integer NOT NULL,
    name character varying(255),
    file character varying(100) NOT NULL,
    uploaded timestamp with time zone NOT NULL
);


ALTER TABLE public.django_summernote_attachment OWNER TO postgres;

--
-- Name: django_summernote_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_summernote_attachment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_summernote_attachment_id_seq OWNER TO postgres;

--
-- Name: django_summernote_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_summernote_attachment_id_seq OWNED BY public.django_summernote_attachment.id;


--
-- Name: events_event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events_event (
    id integer NOT NULL,
    slug character varying(80) NOT NULL,
    name character varying(255) NOT NULL,
    details text NOT NULL,
    location character varying(200) NOT NULL,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone NOT NULL,
    visibility character varying(9) NOT NULL,
    is_published boolean NOT NULL,
    published_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    creator_id integer NOT NULL
);


ALTER TABLE public.events_event OWNER TO postgres;

--
-- Name: events_event_attendees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events_event_attendees (
    id integer NOT NULL,
    event_id integer NOT NULL,
    member_id integer NOT NULL
);


ALTER TABLE public.events_event_attendees OWNER TO postgres;

--
-- Name: events_event_attendees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.events_event_attendees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_event_attendees_id_seq OWNER TO postgres;

--
-- Name: events_event_attendees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.events_event_attendees_id_seq OWNED BY public.events_event_attendees.id;


--
-- Name: events_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.events_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_event_id_seq OWNER TO postgres;

--
-- Name: events_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.events_event_id_seq OWNED BY public.events_event.id;


--
-- Name: events_invitation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events_invitation (
    id integer NOT NULL,
    slug character varying(50) NOT NULL,
    message text NOT NULL,
    is_attending boolean NOT NULL,
    published_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    attendee_id integer NOT NULL,
    event_id integer NOT NULL
);


ALTER TABLE public.events_invitation OWNER TO postgres;

--
-- Name: events_invitation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.events_invitation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_invitation_id_seq OWNER TO postgres;

--
-- Name: events_invitation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.events_invitation_id_seq OWNED BY public.events_invitation.id;


--
-- Name: photos_album; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.photos_album (
    id integer NOT NULL,
    slug character varying(50) NOT NULL,
    name character varying(128) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    owner_id integer NOT NULL
);


ALTER TABLE public.photos_album OWNER TO postgres;

--
-- Name: photos_album_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.photos_album_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.photos_album_id_seq OWNER TO postgres;

--
-- Name: photos_album_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.photos_album_id_seq OWNED BY public.photos_album.id;


--
-- Name: photos_photo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.photos_photo (
    id integer NOT NULL,
    slug character varying(50) NOT NULL,
    url character varying(100),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    album_id integer
);


ALTER TABLE public.photos_photo OWNER TO postgres;

--
-- Name: photos_photo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.photos_photo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.photos_photo_id_seq OWNER TO postgres;

--
-- Name: photos_photo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.photos_photo_id_seq OWNED BY public.photos_photo.id;


--
-- Name: shop_basket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shop_basket (
    id integer NOT NULL,
    slug character varying(50) NOT NULL,
    customer_id integer NOT NULL
);


ALTER TABLE public.shop_basket OWNER TO postgres;

--
-- Name: shop_basket_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shop_basket_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shop_basket_id_seq OWNER TO postgres;

--
-- Name: shop_basket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shop_basket_id_seq OWNED BY public.shop_basket.id;


--
-- Name: shop_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shop_order (
    id integer NOT NULL,
    slug character varying(50) NOT NULL,
    ref_code character varying(15) NOT NULL,
    is_fulfilled boolean NOT NULL,
    date_ordered timestamp with time zone NOT NULL,
    customer_id integer
);


ALTER TABLE public.shop_order OWNER TO postgres;

--
-- Name: shop_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shop_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shop_order_id_seq OWNER TO postgres;

--
-- Name: shop_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shop_order_id_seq OWNED BY public.shop_order.id;


--
-- Name: shop_orderitem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shop_orderitem (
    id integer NOT NULL,
    slug character varying(50) NOT NULL,
    is_fulfilled boolean NOT NULL,
    is_ordered boolean NOT NULL,
    date_added timestamp with time zone NOT NULL,
    date_ordered timestamp with time zone,
    basket_id integer,
    order_id integer,
    product_id integer,
    vendor_id integer
);


ALTER TABLE public.shop_orderitem OWNER TO postgres;

--
-- Name: shop_orderitem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shop_orderitem_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shop_orderitem_id_seq OWNER TO postgres;

--
-- Name: shop_orderitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shop_orderitem_id_seq OWNED BY public.shop_orderitem.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    slug character varying(50) NOT NULL,
    username character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    photo character varying(100),
    name character varying(255) NOT NULL,
    date_of_birth date,
    sex character varying(6),
    is_member boolean NOT NULL
);


ALTER TABLE public.users_user OWNER TO postgres;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO postgres;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO postgres;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO postgres;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: accounts_member id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_member ALTER COLUMN id SET DEFAULT nextval('public.accounts_member_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: campaigns_campaign id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_campaign ALTER COLUMN id SET DEFAULT nextval('public.campaigns_campaign_id_seq'::regclass);


--
-- Name: campaigns_cause id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_cause ALTER COLUMN id SET DEFAULT nextval('public.campaigns_cause_id_seq'::regclass);


--
-- Name: campaigns_cause_supporters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_cause_supporters ALTER COLUMN id SET DEFAULT nextval('public.campaigns_cause_supporters_id_seq'::regclass);


--
-- Name: campaigns_volunteer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_volunteer ALTER COLUMN id SET DEFAULT nextval('public.campaigns_volunteer_id_seq'::regclass);


--
-- Name: catalog_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_category ALTER COLUMN id SET DEFAULT nextval('public.catalog_category_id_seq'::regclass);


--
-- Name: catalog_predefineattributevalue id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_predefineattributevalue ALTER COLUMN id SET DEFAULT nextval('public.catalog_predefineattributevalue_id_seq'::regclass);


--
-- Name: catalog_product id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product ALTER COLUMN id SET DEFAULT nextval('public.catalog_product_id_seq'::regclass);


--
-- Name: catalog_product_attributes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product_attributes ALTER COLUMN id SET DEFAULT nextval('public.catalog_product_attributes_id_seq'::regclass);


--
-- Name: catalog_product_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product_categories ALTER COLUMN id SET DEFAULT nextval('public.catalog_product_categories_id_seq'::regclass);


--
-- Name: catalog_productattribute id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productattribute ALTER COLUMN id SET DEFAULT nextval('public.catalog_productattribute_id_seq'::regclass);


--
-- Name: catalog_productbundle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle ALTER COLUMN id SET DEFAULT nextval('public.catalog_productbundle_id_seq'::regclass);


--
-- Name: catalog_productbundle_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle_categories ALTER COLUMN id SET DEFAULT nextval('public.catalog_productbundle_categories_id_seq'::regclass);


--
-- Name: catalog_productbundle_products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle_products ALTER COLUMN id SET DEFAULT nextval('public.catalog_productbundle_products_id_seq'::regclass);


--
-- Name: discussions_conversation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation ALTER COLUMN id SET DEFAULT nextval('public.discussions_conversation_id_seq'::regclass);


--
-- Name: discussions_conversation_allowed_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation_allowed_members ALTER COLUMN id SET DEFAULT nextval('public.discussions_conversation_allowed_members_id_seq'::regclass);


--
-- Name: discussions_conversation_blacklist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation_blacklist ALTER COLUMN id SET DEFAULT nextval('public.discussions_conversation_blacklist_id_seq'::regclass);


--
-- Name: discussions_discussion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_discussion ALTER COLUMN id SET DEFAULT nextval('public.discussions_discussion_id_seq'::regclass);


--
-- Name: discussions_reply id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_reply ALTER COLUMN id SET DEFAULT nextval('public.discussions_reply_id_seq'::regclass);


--
-- Name: discussions_topic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_topic ALTER COLUMN id SET DEFAULT nextval('public.discussions_topic_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_summernote_attachment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_summernote_attachment ALTER COLUMN id SET DEFAULT nextval('public.django_summernote_attachment_id_seq'::regclass);


--
-- Name: events_event id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_event ALTER COLUMN id SET DEFAULT nextval('public.events_event_id_seq'::regclass);


--
-- Name: events_event_attendees id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_event_attendees ALTER COLUMN id SET DEFAULT nextval('public.events_event_attendees_id_seq'::regclass);


--
-- Name: events_invitation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_invitation ALTER COLUMN id SET DEFAULT nextval('public.events_invitation_id_seq'::regclass);


--
-- Name: photos_album id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.photos_album ALTER COLUMN id SET DEFAULT nextval('public.photos_album_id_seq'::regclass);


--
-- Name: photos_photo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.photos_photo ALTER COLUMN id SET DEFAULT nextval('public.photos_photo_id_seq'::regclass);


--
-- Name: shop_basket id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_basket ALTER COLUMN id SET DEFAULT nextval('public.shop_basket_id_seq'::regclass);


--
-- Name: shop_order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_order ALTER COLUMN id SET DEFAULT nextval('public.shop_order_id_seq'::regclass);


--
-- Name: shop_orderitem id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_orderitem ALTER COLUMN id SET DEFAULT nextval('public.shop_orderitem_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: accounts_member; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.accounts_member VALUES (1, 'daniel', 3);
INSERT INTO public.accounts_member VALUES (2, 'elliot', 4);
INSERT INTO public.accounts_member VALUES (3, 'elyse', 5);
INSERT INTO public.accounts_member VALUES (4, 'helen', 6);
INSERT INTO public.accounts_member VALUES (5, 'jenny', 7);
INSERT INTO public.accounts_member VALUES (6, 'kristy', 8);
INSERT INTO public.accounts_member VALUES (7, 'matthew', 9);
INSERT INTO public.accounts_member VALUES (8, 'molly', 10);
INSERT INTO public.accounts_member VALUES (9, 'sammybear', 2);
INSERT INTO public.accounts_member VALUES (10, 'steve', 11);
INSERT INTO public.accounts_member VALUES (11, 'stevie', 12);
INSERT INTO public.accounts_member VALUES (12, 'veronika', 13);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.auth_permission VALUES (1, 'Can add log entry', 1, 'add_logentry');
INSERT INTO public.auth_permission VALUES (2, 'Can change log entry', 1, 'change_logentry');
INSERT INTO public.auth_permission VALUES (3, 'Can delete log entry', 1, 'delete_logentry');
INSERT INTO public.auth_permission VALUES (4, 'Can view log entry', 1, 'view_logentry');
INSERT INTO public.auth_permission VALUES (5, 'Can add permission', 2, 'add_permission');
INSERT INTO public.auth_permission VALUES (6, 'Can change permission', 2, 'change_permission');
INSERT INTO public.auth_permission VALUES (7, 'Can delete permission', 2, 'delete_permission');
INSERT INTO public.auth_permission VALUES (8, 'Can view permission', 2, 'view_permission');
INSERT INTO public.auth_permission VALUES (9, 'Can add group', 3, 'add_group');
INSERT INTO public.auth_permission VALUES (10, 'Can change group', 3, 'change_group');
INSERT INTO public.auth_permission VALUES (11, 'Can delete group', 3, 'delete_group');
INSERT INTO public.auth_permission VALUES (12, 'Can view group', 3, 'view_group');
INSERT INTO public.auth_permission VALUES (13, 'Can add content type', 4, 'add_contenttype');
INSERT INTO public.auth_permission VALUES (14, 'Can change content type', 4, 'change_contenttype');
INSERT INTO public.auth_permission VALUES (15, 'Can delete content type', 4, 'delete_contenttype');
INSERT INTO public.auth_permission VALUES (16, 'Can view content type', 4, 'view_contenttype');
INSERT INTO public.auth_permission VALUES (17, 'Can add session', 5, 'add_session');
INSERT INTO public.auth_permission VALUES (18, 'Can change session', 5, 'change_session');
INSERT INTO public.auth_permission VALUES (19, 'Can delete session', 5, 'delete_session');
INSERT INTO public.auth_permission VALUES (20, 'Can view session', 5, 'view_session');
INSERT INTO public.auth_permission VALUES (21, 'Can add user', 6, 'add_user');
INSERT INTO public.auth_permission VALUES (22, 'Can change user', 6, 'change_user');
INSERT INTO public.auth_permission VALUES (23, 'Can delete user', 6, 'delete_user');
INSERT INTO public.auth_permission VALUES (24, 'Can view user', 6, 'view_user');
INSERT INTO public.auth_permission VALUES (25, 'Can add member', 7, 'add_member');
INSERT INTO public.auth_permission VALUES (26, 'Can change member', 7, 'change_member');
INSERT INTO public.auth_permission VALUES (27, 'Can delete member', 7, 'delete_member');
INSERT INTO public.auth_permission VALUES (28, 'Can view member', 7, 'view_member');
INSERT INTO public.auth_permission VALUES (29, 'Can add campaign', 8, 'add_campaign');
INSERT INTO public.auth_permission VALUES (30, 'Can change campaign', 8, 'change_campaign');
INSERT INTO public.auth_permission VALUES (31, 'Can delete campaign', 8, 'delete_campaign');
INSERT INTO public.auth_permission VALUES (32, 'Can view campaign', 8, 'view_campaign');
INSERT INTO public.auth_permission VALUES (33, 'Can add volunteer', 9, 'add_volunteer');
INSERT INTO public.auth_permission VALUES (34, 'Can change volunteer', 9, 'change_volunteer');
INSERT INTO public.auth_permission VALUES (35, 'Can delete volunteer', 9, 'delete_volunteer');
INSERT INTO public.auth_permission VALUES (36, 'Can view volunteer', 9, 'view_volunteer');
INSERT INTO public.auth_permission VALUES (37, 'Can add cause', 10, 'add_cause');
INSERT INTO public.auth_permission VALUES (38, 'Can change cause', 10, 'change_cause');
INSERT INTO public.auth_permission VALUES (39, 'Can delete cause', 10, 'delete_cause');
INSERT INTO public.auth_permission VALUES (40, 'Can view cause', 10, 'view_cause');
INSERT INTO public.auth_permission VALUES (41, 'Can add conversation', 11, 'add_conversation');
INSERT INTO public.auth_permission VALUES (42, 'Can change conversation', 11, 'change_conversation');
INSERT INTO public.auth_permission VALUES (43, 'Can delete conversation', 11, 'delete_conversation');
INSERT INTO public.auth_permission VALUES (44, 'Can view conversation', 11, 'view_conversation');
INSERT INTO public.auth_permission VALUES (45, 'Can add discussion', 12, 'add_discussion');
INSERT INTO public.auth_permission VALUES (46, 'Can change discussion', 12, 'change_discussion');
INSERT INTO public.auth_permission VALUES (47, 'Can delete discussion', 12, 'delete_discussion');
INSERT INTO public.auth_permission VALUES (48, 'Can view discussion', 12, 'view_discussion');
INSERT INTO public.auth_permission VALUES (49, 'Can add topic', 13, 'add_topic');
INSERT INTO public.auth_permission VALUES (50, 'Can change topic', 13, 'change_topic');
INSERT INTO public.auth_permission VALUES (51, 'Can delete topic', 13, 'delete_topic');
INSERT INTO public.auth_permission VALUES (52, 'Can view topic', 13, 'view_topic');
INSERT INTO public.auth_permission VALUES (53, 'Can add reply', 14, 'add_reply');
INSERT INTO public.auth_permission VALUES (54, 'Can change reply', 14, 'change_reply');
INSERT INTO public.auth_permission VALUES (55, 'Can delete reply', 14, 'delete_reply');
INSERT INTO public.auth_permission VALUES (56, 'Can view reply', 14, 'view_reply');
INSERT INTO public.auth_permission VALUES (57, 'Can add album', 15, 'add_album');
INSERT INTO public.auth_permission VALUES (58, 'Can change album', 15, 'change_album');
INSERT INTO public.auth_permission VALUES (59, 'Can delete album', 15, 'delete_album');
INSERT INTO public.auth_permission VALUES (60, 'Can view album', 15, 'view_album');
INSERT INTO public.auth_permission VALUES (61, 'Can add photo', 16, 'add_photo');
INSERT INTO public.auth_permission VALUES (62, 'Can change photo', 16, 'change_photo');
INSERT INTO public.auth_permission VALUES (63, 'Can delete photo', 16, 'delete_photo');
INSERT INTO public.auth_permission VALUES (64, 'Can view photo', 16, 'view_photo');
INSERT INTO public.auth_permission VALUES (65, 'Can add event', 17, 'add_event');
INSERT INTO public.auth_permission VALUES (66, 'Can change event', 17, 'change_event');
INSERT INTO public.auth_permission VALUES (67, 'Can delete event', 17, 'delete_event');
INSERT INTO public.auth_permission VALUES (68, 'Can view event', 17, 'view_event');
INSERT INTO public.auth_permission VALUES (69, 'Can add invitation', 18, 'add_invitation');
INSERT INTO public.auth_permission VALUES (70, 'Can change invitation', 18, 'change_invitation');
INSERT INTO public.auth_permission VALUES (71, 'Can delete invitation', 18, 'delete_invitation');
INSERT INTO public.auth_permission VALUES (72, 'Can view invitation', 18, 'view_invitation');
INSERT INTO public.auth_permission VALUES (73, 'Can add category', 19, 'add_category');
INSERT INTO public.auth_permission VALUES (74, 'Can change category', 19, 'change_category');
INSERT INTO public.auth_permission VALUES (75, 'Can delete category', 19, 'delete_category');
INSERT INTO public.auth_permission VALUES (76, 'Can view category', 19, 'view_category');
INSERT INTO public.auth_permission VALUES (77, 'Can add predefined attribute value', 20, 'add_predefineattributevalue');
INSERT INTO public.auth_permission VALUES (78, 'Can change predefined attribute value', 20, 'change_predefineattributevalue');
INSERT INTO public.auth_permission VALUES (79, 'Can delete predefined attribute value', 20, 'delete_predefineattributevalue');
INSERT INTO public.auth_permission VALUES (80, 'Can view predefined attribute value', 20, 'view_predefineattributevalue');
INSERT INTO public.auth_permission VALUES (81, 'Can add product', 21, 'add_product');
INSERT INTO public.auth_permission VALUES (82, 'Can change product', 21, 'change_product');
INSERT INTO public.auth_permission VALUES (83, 'Can delete product', 21, 'delete_product');
INSERT INTO public.auth_permission VALUES (84, 'Can view product', 21, 'view_product');
INSERT INTO public.auth_permission VALUES (85, 'Can add product attribute', 22, 'add_productattribute');
INSERT INTO public.auth_permission VALUES (86, 'Can change product attribute', 22, 'change_productattribute');
INSERT INTO public.auth_permission VALUES (87, 'Can delete product attribute', 22, 'delete_productattribute');
INSERT INTO public.auth_permission VALUES (88, 'Can view product attribute', 22, 'view_productattribute');
INSERT INTO public.auth_permission VALUES (89, 'Can add product bundle', 23, 'add_productbundle');
INSERT INTO public.auth_permission VALUES (90, 'Can change product bundle', 23, 'change_productbundle');
INSERT INTO public.auth_permission VALUES (91, 'Can delete product bundle', 23, 'delete_productbundle');
INSERT INTO public.auth_permission VALUES (92, 'Can view product bundle', 23, 'view_productbundle');
INSERT INTO public.auth_permission VALUES (93, 'Can add basket', 24, 'add_basket');
INSERT INTO public.auth_permission VALUES (94, 'Can change basket', 24, 'change_basket');
INSERT INTO public.auth_permission VALUES (95, 'Can delete basket', 24, 'delete_basket');
INSERT INTO public.auth_permission VALUES (96, 'Can view basket', 24, 'view_basket');
INSERT INTO public.auth_permission VALUES (97, 'Can add order', 25, 'add_order');
INSERT INTO public.auth_permission VALUES (98, 'Can change order', 25, 'change_order');
INSERT INTO public.auth_permission VALUES (99, 'Can delete order', 25, 'delete_order');
INSERT INTO public.auth_permission VALUES (100, 'Can view order', 25, 'view_order');
INSERT INTO public.auth_permission VALUES (101, 'Can add order item', 26, 'add_orderitem');
INSERT INTO public.auth_permission VALUES (102, 'Can change order item', 26, 'change_orderitem');
INSERT INTO public.auth_permission VALUES (103, 'Can delete order item', 26, 'delete_orderitem');
INSERT INTO public.auth_permission VALUES (104, 'Can view order item', 26, 'view_orderitem');
INSERT INTO public.auth_permission VALUES (105, 'Can add attachment', 27, 'add_attachment');
INSERT INTO public.auth_permission VALUES (106, 'Can change attachment', 27, 'change_attachment');
INSERT INTO public.auth_permission VALUES (107, 'Can delete attachment', 27, 'delete_attachment');
INSERT INTO public.auth_permission VALUES (108, 'Can view attachment', 27, 'view_attachment');


--
-- Data for Name: campaigns_campaign; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.campaigns_campaign VALUES (1, '202006165323-aenean-euismod', 'Aenean euismod', 'Fusce quis leo rhoncus sem luctus varius eu in quam. Morbi ut eros vel leo pharetra blandit nec a leo. Mauris nec magna eu dui rhoncus accumsan eu vitae purus. Maecenas pharetra elit eget sem hendrerit, quis scelerisque libero condimentum. Suspendisse malesuada pulvinar metus ac faucibus. Maecenas aliquam, quam ac malesuada faucibus, lectus diam venenatis enim, vitae auctor est ex pellentesque risus. Phasellus ut accumsan neque, ac lobortis magna.', 5000.00, 0.00, 0.00, true, true, 'Nam hendrerit eros sed dolor sodales, vitae molestie libero pellentesque. Sed ac vulputate eros. In hac habitasse platea dictumst. Sed dui dui, ornare quis nisi sit amet, posuere congue felis.', 3, 6, 9);
INSERT INTO public.campaigns_campaign VALUES (2, '202006165615-maecenas-id-massa-dolor', 'Maecenas id massa dolor', 'Aliquam vestibulum elementum diam malesuada porta. Sed ac sagittis diam. Donec nec volutpat sem. Sed sit amet iaculis nulla. Vestibulum finibus vehicula consequat. Fusce id molestie tortor. Praesent bibendum dictum augue et sollicitudin. Aenean id mauris sed est laoreet maximus non nec est. Donec lectus dolor, congue in dictum semper, fringilla non enim.', 5000.00, 0.00, 0.00, true, true, 'Fusce consequat suscipit elit, sit amet vehicula ante. Ut finibus libero neque, id fringilla massa laoreet ac. In hac habitasse platea dictumst. Integer blandit ante condimentum dictum sollicitudin.', 3, 13, 2);
INSERT INTO public.campaigns_campaign VALUES (3, '202006165752-integer-vel-dignissim-tellus', 'Integer vel dignissim tellus', 'Sed ac velit ac sem auctor venenatis et a nunc. Donec vel dapibus nisi. Sed hendrerit erat vel augue imperdiet luctus. Nam sed mattis ex. Suspendisse quis dui quis mauris sollicitudin dictum nec et dui. Donec a volutpat velit. Mauris ac molestie arcu. Aliquam pharetra tempor velit. Donec mi nibh, ullamcorper vel tellus sit amet, porta congue turpis.', 5000.00, 0.00, 0.00, true, true, 'Nulla tincidunt felis et libero ullamcorper scelerisque. Donec in cursus dolor, a tempor leo. Aenean sem turpis, convallis vitae volutpat sit amet, volutpat ut mi. Cras sit amet lorem id enim fringilla hendrerit.', 3, 14, 8);


--
-- Data for Name: campaigns_cause; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.campaigns_cause VALUES (1, 'animal-rights', 'Animal Rights', 'Animals');
INSERT INTO public.campaigns_cause VALUES (2, 'animal-welfare', 'Animal Welfare', 'Animals');
INSERT INTO public.campaigns_cause VALUES (3, 'wildlife-conservation', 'Wildlife Conservation', 'Animals');
INSERT INTO public.campaigns_cause VALUES (4, 'environmental-protection-and-conservation', 'Environmental Protection and Conservation', 'Environment');
INSERT INTO public.campaigns_cause VALUES (5, 'environmental-rights', 'Environmental Rights', 'Environment');
INSERT INTO public.campaigns_cause VALUES (6, 'arts-culture', 'Arts & Culture', 'Humans');
INSERT INTO public.campaigns_cause VALUES (7, 'athletics', 'Athletics', 'Humans');
INSERT INTO public.campaigns_cause VALUES (8, 'community-organizations', 'Community Organizations', 'Humans');
INSERT INTO public.campaigns_cause VALUES (9, 'community-development', 'Community Development', 'Humans');
INSERT INTO public.campaigns_cause VALUES (10, 'conflict-resolution', 'Conflict Resolution', 'Humans');
INSERT INTO public.campaigns_cause VALUES (11, 'criminal-justices', 'Criminal Justices', 'Humans');
INSERT INTO public.campaigns_cause VALUES (12, 'economics', 'Economics', 'Humans');
INSERT INTO public.campaigns_cause VALUES (13, 'education', 'Education', 'Humans');
INSERT INTO public.campaigns_cause VALUES (14, 'health', 'Health', 'Humans');
INSERT INTO public.campaigns_cause VALUES (15, 'housing-and-shelter', 'Housing and Shelter', 'Humans');
INSERT INTO public.campaigns_cause VALUES (16, 'hunger-and-food-security', 'Hunger and Food Security', 'Humans');
INSERT INTO public.campaigns_cause VALUES (17, 'human-and-civil-rights', 'Human and Civil Rights', 'Humans');
INSERT INTO public.campaigns_cause VALUES (18, 'transportation', 'Transportation', 'Humans');
INSERT INTO public.campaigns_cause VALUES (19, 'victims-of-abuse-and-neglect', 'Victims of Abuse and Neglect', 'Humans');
INSERT INTO public.campaigns_cause VALUES (20, 'children-and-family', 'Children and Family', 'Humans');
INSERT INTO public.campaigns_cause VALUES (21, 'religion', 'Religion', 'Humans');


--
-- Data for Name: campaigns_cause_supporters; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: campaigns_volunteer; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.campaigns_volunteer VALUES (1, '43cc500b-b026-11ea-9a09-43acd4e74c10', 'Nunc nunc felis, pretium ut viverra tempor, malesuada ac magna. Vivamus varius feugiat urna vel faucibus.', 'Accepted', 1, 12);
INSERT INTO public.campaigns_volunteer VALUES (2, 'bf5b7f0d-b026-11ea-9a09-43acd4e74c10', 'Nunc nunc felis, pretium ut viverra tempor, malesuada ac magna. Vivamus varius feugiat urna vel faucibus.', 'Pending', 1, 11);
INSERT INTO public.campaigns_volunteer VALUES (3, 'dae8079b-b026-11ea-9a09-43acd4e74c10', 'Sed non velit a nibh iaculis ultricies a id nisi. Sed at ultrices neque. Morbi efficitur enim eget placerat aliquet. Cras mollis vel dolor quis eleifend.', 'Accepted', 2, 1);
INSERT INTO public.campaigns_volunteer VALUES (4, '7e281ea5-b027-11ea-9a09-43acd4e74c10', 'Sed non velit a nibh iaculis ultricies a id nisi. Sed at ultrices neque. Morbi efficitur enim eget placerat aliquet. Cras mollis vel dolor quis eleifend.', 'Pending', 2, 3);
INSERT INTO public.campaigns_volunteer VALUES (5, '8c6e0add-b027-11ea-9a09-43acd4e74c10', 'Morbi ornare ut sem eget sollicitudin. Morbi porta pretium velit sit amet euismod. Proin tincidunt, tortor sed aliquet bibendum, ligula metus bibendum nunc, vitae vulputate nisl ante eu nisi.', 'Accepted', 3, 7);
INSERT INTO public.campaigns_volunteer VALUES (6, 'acc716fd-b027-11ea-9a09-43acd4e74c10', 'Morbi ornare ut sem eget sollicitudin. Morbi porta pretium velit sit amet euismod. Proin tincidunt, tortor sed aliquet bibendum, ligula metus bibendum nunc, vitae vulputate nisl ante eu nisi.', 'Pending', 3, 6);


--
-- Data for Name: catalog_category; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: catalog_predefineattributevalue; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: catalog_product; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: catalog_product_attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: catalog_product_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: catalog_productattribute; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: catalog_productbundle; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: catalog_productbundle_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: catalog_productbundle_products; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: discussions_conversation; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: discussions_conversation_allowed_members; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: discussions_conversation_blacklist; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: discussions_discussion; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.discussions_discussion VALUES (1, 'animals', 'Animals', 'Aliquam faucibus porttitor elit, sed ultricies massa. Quisque varius sit amet dui ac rutrum. Suspendisse tincidunt pharetra ligula. Maecenas tortor mauris, venenatis at placerat sit amet, imperdiet eget massa.');
INSERT INTO public.discussions_discussion VALUES (2, 'environment', 'Environment', 'Aliquam faucibus porttitor elit, sed ultricies massa. Quisque varius sit amet dui ac rutrum. Suspendisse tincidunt pharetra ligula. Maecenas tortor mauris, venenatis at placerat sit amet, imperdiet eget massa.');
INSERT INTO public.discussions_discussion VALUES (3, 'humans', 'Humans', 'Aliquam faucibus porttitor elit, sed ultricies massa. Quisque varius sit amet dui ac rutrum. Suspendisse tincidunt pharetra ligula. Maecenas tortor mauris, venenatis at placerat sit amet, imperdiet eget massa.');


--
-- Data for Name: discussions_reply; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: discussions_topic; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.discussions_topic VALUES (1, '202006165009-environmental-contamination', 'Environmental Contamination', 'Aliquam faucibus porttitor elit, sed ultricies massa. Quisque varius sit amet dui ac rutrum. Suspendisse tincidunt pharetra ligula. Maecenas tortor mauris, venenatis at placerat sit amet, imperdiet eget massa.', NULL, 2);
INSERT INTO public.discussions_topic VALUES (2, '202006165049-community-development', 'Community Development', 'Aliquam faucibus porttitor elit, sed ultricies massa. Quisque varius sit amet dui ac rutrum. Suspendisse tincidunt pharetra ligula. Maecenas tortor mauris, venenatis at placerat sit amet, imperdiet eget massa.', NULL, 3);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.django_admin_log VALUES (1, '2020-06-16 14:40:19.322827-07', '2', 'sammybear', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (2, '2020-06-16 14:42:26.975314-07', '3', 'daniel', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (3, '2020-06-16 14:43:39.354738-07', '4', 'elliot', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (4, '2020-06-16 14:45:32.849893-07', '5', 'elyse', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (5, '2020-06-16 14:57:17.603473-07', '6', 'helen', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (6, '2020-06-16 14:58:42.516863-07', '7', 'jenny', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (7, '2020-06-16 14:59:29.105954-07', '8', 'kristy', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (8, '2020-06-16 15:01:56.774742-07', '9', 'matthew', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (9, '2020-06-16 15:02:44.180696-07', '10', 'molly', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (10, '2020-06-16 15:03:22.824931-07', '11', 'stevie', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (11, '2020-06-16 15:04:36.835167-07', '11', 'steve', 2, '[{"changed": {"fields": ["username", "sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (12, '2020-06-16 15:05:28.045564-07', '12', 'stevie', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (13, '2020-06-16 15:07:03.411874-07', '13', 'veronika', 1, '[{"added": {}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (14, '2020-06-16 15:07:18.94406-07', '13', 'veronika', 2, '[{"changed": {"fields": ["sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (15, '2020-06-16 15:07:40.573671-07', '3', 'daniel', 2, '[{"changed": {"fields": ["sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (16, '2020-06-16 15:08:08.125461-07', '4', 'elliot', 2, '[{"changed": {"fields": ["sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (17, '2020-06-16 15:08:30.198389-07', '5', 'elyse', 2, '[{"changed": {"fields": ["sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (18, '2020-06-16 15:08:51.94271-07', '6', 'helen', 2, '[{"changed": {"fields": ["sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (19, '2020-06-16 15:09:12.519547-07', '7', 'jenny', 2, '[{"changed": {"fields": ["sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (20, '2020-06-16 15:09:52.638258-07', '8', 'kristy', 2, '[{"changed": {"fields": ["sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (21, '2020-06-16 15:10:07.896659-07', '9', 'matthew', 2, '[{"changed": {"fields": ["sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (22, '2020-06-16 15:10:46.961464-07', '10', 'molly', 2, '[{"changed": {"fields": ["sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (23, '2020-06-16 15:11:19.652229-07', '2', 'sammybear', 2, '[{"changed": {"fields": ["sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (24, '2020-06-16 15:11:49.778541-07', '12', 'stevie', 2, '[{"changed": {"fields": ["sex", "is_member"]}}]', 6, 1);
INSERT INTO public.django_admin_log VALUES (25, '2020-06-16 15:12:09.600982-07', '1', 'daniel', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (26, '2020-06-16 15:12:16.557721-07', '2', 'elliot', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (27, '2020-06-16 15:12:22.014114-07', '3', 'elyse', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (28, '2020-06-16 15:12:27.928086-07', '4', 'helen', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (29, '2020-06-16 15:12:34.214726-07', '5', 'jenny', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (30, '2020-06-16 15:12:40.275934-07', '6', 'kristy', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (31, '2020-06-16 15:12:51.483236-07', '7', 'matthew', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (32, '2020-06-16 15:12:57.737539-07', '8', 'molly', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (33, '2020-06-16 15:13:05.039251-07', '9', 'sammybear', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (34, '2020-06-16 15:13:11.418309-07', '10', 'steve', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (35, '2020-06-16 15:13:50.469527-07', '11', 'stevie', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (36, '2020-06-16 15:13:59.938742-07', '12', 'veronika', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (37, '2020-06-16 15:23:44.006003-07', '1', 'Animal Rights', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (38, '2020-06-16 15:24:15.173664-07', '2', 'Animal Welfare', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (39, '2020-06-16 15:24:24.010473-07', '3', 'Wildlife Conservation', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (40, '2020-06-16 15:24:43.205626-07', '4', 'Environmental Protection and Conservation', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (41, '2020-06-16 15:25:44.228533-07', '5', 'Environmental Rights', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (42, '2020-06-16 15:28:49.854533-07', '6', 'Arts & Culture', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (43, '2020-06-16 15:29:07.720379-07', '7', 'Athletics', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (44, '2020-06-16 15:29:51.162393-07', '8', 'Community Organizations', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (45, '2020-06-16 15:31:35.717689-07', '9', 'Community Development', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (46, '2020-06-16 15:31:56.24108-07', '10', 'Conflict Resolution', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (47, '2020-06-16 15:33:39.674917-07', '11', 'Criminal Justices', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (48, '2020-06-16 15:34:03.145641-07', '12', 'Economics', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (49, '2020-06-16 15:34:26.053893-07', '13', 'Education', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (50, '2020-06-16 15:34:54.432734-07', '14', 'Health', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (51, '2020-06-16 15:35:56.77803-07', '15', 'Housing and Shelter', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (52, '2020-06-16 15:36:12.911244-07', '16', 'Hunger and Food Security', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (53, '2020-06-16 15:42:34.074521-07', '17', 'Human and Civil Rights', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (54, '2020-06-16 15:42:57.826855-07', '18', 'Transportation', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (55, '2020-06-16 15:43:40.727832-07', '19', 'Victims of Abuse and Neglect', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (56, '2020-06-16 15:44:16.285414-07', '20', 'Children and Family', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (57, '2020-06-16 15:45:16.526683-07', '21', 'Religion', 1, '[{"added": {}}]', 10, 1);
INSERT INTO public.django_admin_log VALUES (58, '2020-06-16 15:53:23.361433-07', '1', 'Aenean euismod', 1, '[{"added": {}}]', 8, 1);
INSERT INTO public.django_admin_log VALUES (59, '2020-06-16 15:56:15.815751-07', '2', 'Maecenas id massa dolor', 1, '[{"added": {}}]', 8, 1);
INSERT INTO public.django_admin_log VALUES (60, '2020-06-16 15:57:52.863872-07', '3', 'Integer vel dignissim tellus', 1, '[{"added": {}}]', 8, 1);
INSERT INTO public.django_admin_log VALUES (61, '2020-06-16 16:11:45.366596-07', '1', 'veronika for Aenean euismod', 1, '[{"added": {}}]', 9, 1);
INSERT INTO public.django_admin_log VALUES (62, '2020-06-16 16:12:31.580135-07', '2', 'stevie for Aenean euismod', 1, '[{"added": {}}]', 9, 1);
INSERT INTO public.django_admin_log VALUES (63, '2020-06-16 16:15:35.183615-07', '3', 'Daniel Nile for Maecenas id massa dolor', 1, '[{"added": {}}]', 9, 1);
INSERT INTO public.django_admin_log VALUES (64, '2020-06-16 16:17:29.414457-07', '4', 'Elyse Lee for Maecenas id massa dolor', 1, '[{"added": {}}]', 9, 1);
INSERT INTO public.django_admin_log VALUES (65, '2020-06-16 16:18:23.691605-07', '5', 'Matthew Tam for Integer vel dignissim tellus', 1, '[{"added": {}}]', 9, 1);
INSERT INTO public.django_admin_log VALUES (66, '2020-06-16 16:19:54.269517-07', '6', 'Kristy Risk for Integer vel dignissim tellus', 1, '[{"added": {}}]', 9, 1);
INSERT INTO public.django_admin_log VALUES (67, '2020-06-16 16:32:16.202307-07', '1', 'Quisque sodales', 1, '[{"added": {}}]', 17, 1);
INSERT INTO public.django_admin_log VALUES (68, '2020-06-16 16:42:16.3547-07', '2', 'Orci varius natoque', 1, '[{"added": {}}]', 17, 1);
INSERT INTO public.django_admin_log VALUES (69, '2020-06-16 16:44:07.648744-07', '3', 'Aliquam commodo', 1, '[{"added": {}}]', 17, 1);
INSERT INTO public.django_admin_log VALUES (70, '2020-06-16 16:45:17.847339-07', '1', 'Stevie Eve has been invited to Quisque sodales', 1, '[{"added": {}}]', 18, 1);
INSERT INTO public.django_admin_log VALUES (71, '2020-06-16 16:45:53.769212-07', '2', 'Elyse Lee has been invited to Orci varius natoque', 1, '[{"added": {}}]', 18, 1);
INSERT INTO public.django_admin_log VALUES (72, '2020-06-16 16:47:11.513276-07', '3', 'Kristy Risk has been invited to Aliquam commodo', 1, '[{"added": {}}]', 18, 1);
INSERT INTO public.django_admin_log VALUES (73, '2020-06-16 16:48:16.223785-07', '1', 'Animals', 1, '[{"added": {}}]', 12, 1);
INSERT INTO public.django_admin_log VALUES (74, '2020-06-16 16:48:27.547444-07', '2', 'Environment', 1, '[{"added": {}}]', 12, 1);
INSERT INTO public.django_admin_log VALUES (75, '2020-06-16 16:48:38.515014-07', '3', 'Humans', 1, '[{"added": {}}]', 12, 1);
INSERT INTO public.django_admin_log VALUES (76, '2020-06-16 16:50:09.91681-07', '1', 'Environmental Contamination', 1, '[{"added": {}}]', 13, 1);
INSERT INTO public.django_admin_log VALUES (77, '2020-06-16 16:50:49.736601-07', '2', 'Community Development', 1, '[{"added": {}}]', 13, 1);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.django_content_type VALUES (1, 'admin', 'logentry');
INSERT INTO public.django_content_type VALUES (2, 'auth', 'permission');
INSERT INTO public.django_content_type VALUES (3, 'auth', 'group');
INSERT INTO public.django_content_type VALUES (4, 'contenttypes', 'contenttype');
INSERT INTO public.django_content_type VALUES (5, 'sessions', 'session');
INSERT INTO public.django_content_type VALUES (6, 'users', 'user');
INSERT INTO public.django_content_type VALUES (7, 'accounts', 'member');
INSERT INTO public.django_content_type VALUES (8, 'campaigns', 'campaign');
INSERT INTO public.django_content_type VALUES (9, 'campaigns', 'volunteer');
INSERT INTO public.django_content_type VALUES (10, 'campaigns', 'cause');
INSERT INTO public.django_content_type VALUES (11, 'discussions', 'conversation');
INSERT INTO public.django_content_type VALUES (12, 'discussions', 'discussion');
INSERT INTO public.django_content_type VALUES (13, 'discussions', 'topic');
INSERT INTO public.django_content_type VALUES (14, 'discussions', 'reply');
INSERT INTO public.django_content_type VALUES (15, 'photos', 'album');
INSERT INTO public.django_content_type VALUES (16, 'photos', 'photo');
INSERT INTO public.django_content_type VALUES (17, 'events', 'event');
INSERT INTO public.django_content_type VALUES (18, 'events', 'invitation');
INSERT INTO public.django_content_type VALUES (19, 'catalog', 'category');
INSERT INTO public.django_content_type VALUES (20, 'catalog', 'predefineattributevalue');
INSERT INTO public.django_content_type VALUES (21, 'catalog', 'product');
INSERT INTO public.django_content_type VALUES (22, 'catalog', 'productattribute');
INSERT INTO public.django_content_type VALUES (23, 'catalog', 'productbundle');
INSERT INTO public.django_content_type VALUES (24, 'shop', 'basket');
INSERT INTO public.django_content_type VALUES (25, 'shop', 'order');
INSERT INTO public.django_content_type VALUES (26, 'shop', 'orderitem');
INSERT INTO public.django_content_type VALUES (27, 'django_summernote', 'attachment');


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.django_migrations VALUES (1, 'contenttypes', '0001_initial', '2020-06-16 14:31:12.002143-07');
INSERT INTO public.django_migrations VALUES (2, 'contenttypes', '0002_remove_content_type_name', '2020-06-16 14:31:12.015309-07');
INSERT INTO public.django_migrations VALUES (3, 'auth', '0001_initial', '2020-06-16 14:31:12.048013-07');
INSERT INTO public.django_migrations VALUES (4, 'auth', '0002_alter_permission_name_max_length', '2020-06-16 14:31:12.077297-07');
INSERT INTO public.django_migrations VALUES (5, 'auth', '0003_alter_user_email_max_length', '2020-06-16 14:31:12.087522-07');
INSERT INTO public.django_migrations VALUES (6, 'auth', '0004_alter_user_username_opts', '2020-06-16 14:31:12.102531-07');
INSERT INTO public.django_migrations VALUES (7, 'auth', '0005_alter_user_last_login_null', '2020-06-16 14:31:12.115566-07');
INSERT INTO public.django_migrations VALUES (8, 'auth', '0006_require_contenttypes_0002', '2020-06-16 14:31:12.119413-07');
INSERT INTO public.django_migrations VALUES (9, 'auth', '0007_alter_validators_add_error_messages', '2020-06-16 14:31:12.133441-07');
INSERT INTO public.django_migrations VALUES (10, 'auth', '0008_alter_user_username_max_length', '2020-06-16 14:31:12.142331-07');
INSERT INTO public.django_migrations VALUES (11, 'auth', '0009_alter_user_last_name_max_length', '2020-06-16 14:31:12.15141-07');
INSERT INTO public.django_migrations VALUES (12, 'auth', '0010_alter_group_name_max_length', '2020-06-16 14:31:12.162373-07');
INSERT INTO public.django_migrations VALUES (13, 'auth', '0011_update_proxy_permissions', '2020-06-16 14:31:12.175287-07');
INSERT INTO public.django_migrations VALUES (14, 'users', '0001_initial', '2020-06-16 14:31:12.209879-07');
INSERT INTO public.django_migrations VALUES (15, 'accounts', '0001_initial', '2020-06-16 14:31:12.244382-07');
INSERT INTO public.django_migrations VALUES (16, 'accounts', '0002_member_user', '2020-06-16 14:31:12.262136-07');
INSERT INTO public.django_migrations VALUES (17, 'admin', '0001_initial', '2020-06-16 14:31:12.287492-07');
INSERT INTO public.django_migrations VALUES (18, 'admin', '0002_logentry_remove_auto_add', '2020-06-16 14:31:12.342478-07');
INSERT INTO public.django_migrations VALUES (19, 'admin', '0003_logentry_add_action_flag_choices', '2020-06-16 14:31:12.351318-07');
INSERT INTO public.django_migrations VALUES (20, 'campaigns', '0001_initial', '2020-06-16 14:31:12.432891-07');
INSERT INTO public.django_migrations VALUES (21, 'photos', '0001_initial', '2020-06-16 14:31:12.492546-07');
INSERT INTO public.django_migrations VALUES (22, 'catalog', '0001_initial', '2020-06-16 14:31:12.561815-07');
INSERT INTO public.django_migrations VALUES (23, 'catalog', '0002_auto_20200616_2130', '2020-06-16 14:31:12.73883-07');
INSERT INTO public.django_migrations VALUES (24, 'discussions', '0001_initial', '2020-06-16 14:31:12.955865-07');
INSERT INTO public.django_migrations VALUES (25, 'django_summernote', '0001_initial', '2020-06-16 14:31:13.022053-07');
INSERT INTO public.django_migrations VALUES (26, 'django_summernote', '0002_update-help_text', '2020-06-16 14:31:13.030085-07');
INSERT INTO public.django_migrations VALUES (27, 'events', '0001_initial', '2020-06-16 14:31:13.124127-07');
INSERT INTO public.django_migrations VALUES (28, 'photos', '0002_album_owner', '2020-06-16 14:31:13.193005-07');
INSERT INTO public.django_migrations VALUES (29, 'sessions', '0001_initial', '2020-06-16 14:31:13.208185-07');
INSERT INTO public.django_migrations VALUES (30, 'shop', '0001_initial', '2020-06-16 14:31:13.368709-07');


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.django_session VALUES ('slzi26q60r12jdgy63ccyubn3u1f4a8j', 'Y2Y0YTc0NTIxOWY2MzcwYTQwYTdlYzlkMTAxNjQxYjAyYjdkNjZlZTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MjE4YTFiMmUwYzNkNDE4MjJmZjUyYzYyZGIxODg1NWMzZjk0YjlkIn0=', '2020-06-30 14:37:23.827029-07');


--
-- Data for Name: django_summernote_attachment; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: events_event; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.events_event VALUES (1, '202006163216-quisque-sodales', 'Quisque sodales', 'Nullam lobortis sapien a diam volutpat, id rhoncus eros mollis. Proin urna lacus, ultricies sit amet eleifend sed, accumsan in sapien. Sed vel efficitur sapien, in sagittis neque. Aliquam efficitur metus sit amet convallis luctus. Phasellus finibus eget justo sit amet venenatis. Aliquam lobortis est a nisi consectetur, non faucibus ligula luctus. Mauris interdum est vitae placerat interdum. Morbi sit amet dapibus sapien. In a tellus blandit, condimentum dolor vel, venenatis ante. Etiam a sem enim.', '123 Fake St.', '2020-06-22 03:00:00-07', '2020-06-22 05:00:00-07', 'Public', true, '2020-06-16 16:29:33-07', '2020-06-16 16:32:16.195829-07', '2020-06-16 16:32:16.195847-07', 9);
INSERT INTO public.events_event VALUES (2, '202006164216-orci-varius-natoque', 'Orci varius natoque', 'Donec gravida nunc eu lorem mattis, at iaculis augue lacinia. Aenean libero felis, vestibulum id suscipit in, vulputate non risus. Duis quis egestas lectus. Integer tincidunt blandit tellus, viverra aliquam purus efficitur et.', '123 Fake St.', '2020-06-22 03:00:00-07', '2020-06-22 05:00:00-07', 'Public', true, '2020-06-16 16:41:05-07', '2020-06-16 16:42:16.351665-07', '2020-06-16 16:42:16.351681-07', 2);
INSERT INTO public.events_event VALUES (3, '202006164407-aliquam-commodo', 'Aliquam commodo', 'In quis suscipit ipsum, non mollis libero. Maecenas suscipit sapien non mi imperdiet fermentum. Aliquam faucibus porttitor elit, sed ultricies massa. Quisque varius sit amet dui ac rutrum. Suspendisse tincidunt pharetra ligula. Maecenas tortor mauris, venenatis at placerat sit amet, imperdiet eget massa.', '123 Fake St.', '2020-06-22 03:00:00-07', '2020-06-22 05:00:00-07', 'Public', true, '2020-06-16 16:43:46-07', '2020-06-16 16:44:07.644269-07', '2020-06-16 16:44:07.644281-07', 8);


--
-- Data for Name: events_event_attendees; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.events_event_attendees VALUES (1, 1, 12);
INSERT INTO public.events_event_attendees VALUES (2, 3, 7);


--
-- Data for Name: events_invitation; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.events_invitation VALUES (1, '4c12cafb-b02b-11ea-9a09-43acd4e74c10', 'In quis suscipit ipsum, non mollis libero. Maecenas suscipit sapien non mi imperdiet fermentum. Aliquam faucibus porttitor elit, sed ultricies massa. Quisque varius sit amet dui ac rutrum. Suspendisse tincidunt pharetra ligula. Maecenas tortor mauris, venenatis at placerat sit amet, imperdiet eget massa.', false, '2020-06-16 16:45:09-07', '2020-06-16 16:45:17.844076-07', '2020-06-16 16:45:17.844098-07', 11, 1);
INSERT INTO public.events_invitation VALUES (2, '6ee42903-b02b-11ea-9a09-43acd4e74c10', 'In quis suscipit ipsum, non mollis libero. Maecenas suscipit sapien non mi imperdiet fermentum. Aliquam faucibus porttitor elit, sed ultricies massa. Quisque varius sit amet dui ac rutrum. Suspendisse tincidunt pharetra ligula. Maecenas tortor mauris, venenatis at placerat sit amet, imperdiet eget massa.', false, '2020-06-16 16:45:50-07', '2020-06-16 16:45:53.766787-07', '2020-06-16 16:45:53.766807-07', 3, 2);
INSERT INTO public.events_invitation VALUES (3, '844d3cc1-b02b-11ea-9a09-43acd4e74c10', 'In quis suscipit ipsum, non mollis libero. Maecenas suscipit sapien non mi imperdiet fermentum. Aliquam faucibus porttitor elit, sed ultricies massa. Quisque varius sit amet dui ac rutrum. Suspendisse tincidunt pharetra ligula. Maecenas tortor mauris, venenatis at placerat sit amet, imperdiet eget massa.', false, '2020-06-16 16:47:08-07', '2020-06-16 16:47:11.509415-07', '2020-06-16 16:47:11.509431-07', 6, 3);


--
-- Data for Name: photos_album; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: photos_photo; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: shop_basket; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: shop_order; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: shop_orderitem; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.users_user VALUES (1, 'pbkdf2_sha256$150000$FKunZUrwGvpF$VYv1V6G45PPf1LkdIJuUTBPBiHazY3E/m5FR01ik+qs=', '2020-06-16 14:37:23.824702-07', true, true, true, '2020-06-16 14:36:29.771949-07', '7092e41d-b019-11ea-9a09-43acd4e74c10', 'sudo', 'sudo@local.com', '', 'Super User', NULL, NULL, false);
INSERT INTO public.users_user VALUES (11, 'pbkdf2_sha256$150000$cPLDO58zOeLW$o+GMerUANaiFLRCcTIMoB+L62O9ZmLigz5EjIoogDa8=', NULL, false, false, true, '2020-06-16 15:03:22-07', '31fd92de-b01d-11ea-9a09-43acd4e74c10', 'steve', 'steve@local.com', 'stevie/steve.jpg', 'Steve Ves', NULL, 'Male', true);
INSERT INTO public.users_user VALUES (13, 'pbkdf2_sha256$150000$hN3fvQW9NPGm$8zm/EwNFIEY/mmLYCnjvyVvi/CHmC/P6j+WwgasExUw=', NULL, false, false, true, '2020-06-16 15:07:03-07', 'b5796f84-b01d-11ea-9a09-43acd4e74c10', 'veronika', 'veronika@local.com', 'veronika/veronika.jpg', 'Veronika Nova', NULL, 'Female', true);
INSERT INTO public.users_user VALUES (3, 'pbkdf2_sha256$150000$cieTZyOkcyXu$dWpe3UgL11iikEza/G/mFl4Dio7Mqx4njPrCTxIhnb4=', NULL, false, false, true, '2020-06-16 14:42:26-07', '4573674c-b01a-11ea-9a09-43acd4e74c10', 'daniel', 'daniel@local.com', 'daniel/daniel.jpg', 'Daniel Nile', NULL, 'Male', true);
INSERT INTO public.users_user VALUES (4, 'pbkdf2_sha256$150000$ntFC8Htz2yxH$Fjy7m6tHyPdJu/A5/qkxjzqCHY9IEE9cfFJJc3ijU9Y=', NULL, false, false, true, '2020-06-16 14:43:39-07', '70972f44-b01a-11ea-9a09-43acd4e74c10', 'elliot', 'elliot@local.com', 'elliot/elliot.jpg', 'Elliot Lot', NULL, 'Male', true);
INSERT INTO public.users_user VALUES (5, 'pbkdf2_sha256$150000$9V5pfQHk9Dqi$5UnbInG9RsFF2FhDJouxkMrqc7TTLkhJYjrqSTQJRrQ=', NULL, false, false, true, '2020-06-16 14:45:32-07', 'b43d339c-b01a-11ea-9a09-43acd4e74c10', 'elyse', 'elyse@local.com', 'elyse/elyse.png', 'Elyse Lee', NULL, 'Female', true);
INSERT INTO public.users_user VALUES (6, 'pbkdf2_sha256$150000$Cj4cDvC0IXZt$tnAxMm1Vva/AcGYCBngjr6tvSmMPH8x31n0QGwCIcME=', NULL, false, false, true, '2020-06-16 14:57:17-07', '584e5dde-b01c-11ea-9a09-43acd4e74c10', 'helen', 'helen@local.com', 'helen/helen.jpg', 'Helen Len', NULL, 'Female', true);
INSERT INTO public.users_user VALUES (7, 'pbkdf2_sha256$150000$sBgOsWoHQr6j$U+MiOLMhoswGYl3fFlCZajjs/Jrg1eKlSKw8FFPnojo=', NULL, false, false, true, '2020-06-16 14:58:42-07', '8aeb80c8-b01c-11ea-9a09-43acd4e74c10', 'jenny', 'jenny@local.com', 'jenny/jenny.jpg', 'Jenny Yej', NULL, 'Female', true);
INSERT INTO public.users_user VALUES (8, 'pbkdf2_sha256$150000$BAWn7wr488Uj$LdoRckicMVz+XeTeewlfOK27pIEBYdXrOQ0/d9HvttI=', NULL, false, false, true, '2020-06-16 14:59:29-07', 'a6b015e4-b01c-11ea-9a09-43acd4e74c10', 'kristy', 'kristy@local.com', '', 'Kristy Risk', NULL, 'Female', true);
INSERT INTO public.users_user VALUES (9, 'pbkdf2_sha256$150000$C5CRLetk1mDR$2GTLzFnRBCbro0jDUwefyrDiTYQWaNbdnxXxzU2b/Uc=', NULL, false, false, true, '2020-06-16 15:01:56-07', 'feb4544e-b01c-11ea-9a09-43acd4e74c10', 'matthew', 'matthew@local.com', 'matthew/matthew.png', 'Matthew Tam', NULL, 'Male', true);
INSERT INTO public.users_user VALUES (10, 'pbkdf2_sha256$150000$UzvXSBu1Rbk9$BTNS2vVTzWrFOaZXScTp+TuJv9pRSd0lHpd53L4+wFo=', NULL, false, false, true, '2020-06-16 15:02:44-07', '1af612d2-b01d-11ea-9a09-43acd4e74c10', 'molly', 'molly@local.com', 'molly/molly.png', 'Molly Knight', NULL, 'Female', true);
INSERT INTO public.users_user VALUES (2, 'pbkdf2_sha256$150000$UiQ3cWsZQehu$hcdkytgS0YhBjVBYLHtt8x0kjakGKAZoFZqT+2QuYMU=', NULL, false, false, true, '2020-06-16 14:40:19-07', 'f9541488-b019-11ea-9a09-43acd4e74c10', 'sammybear', 'sammybear@local.com', 'sammybear/nan.jpg', 'Samantha Bear', NULL, 'Female', true);
INSERT INTO public.users_user VALUES (12, 'pbkdf2_sha256$150000$5iCNfTa8tXpZ$TqVTEPB1kVf2lSQ2l+Ces9LVt75WBBBB8XFgBNu8OvE=', NULL, false, false, true, '2020-06-16 15:05:27-07', '7ca16432-b01d-11ea-9a09-43acd4e74c10', 'stevie', 'stevie@local.com', 'stevie/stevie.jpg', 'Stevie Eve', NULL, 'Female', true);


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: accounts_member_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_member_id_seq', 12, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 108, true);


--
-- Name: campaigns_campaign_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campaigns_campaign_id_seq', 3, true);


--
-- Name: campaigns_cause_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campaigns_cause_id_seq', 21, true);


--
-- Name: campaigns_cause_supporters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campaigns_cause_supporters_id_seq', 1, false);


--
-- Name: campaigns_volunteer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campaigns_volunteer_id_seq', 6, true);


--
-- Name: catalog_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_category_id_seq', 1, false);


--
-- Name: catalog_predefineattributevalue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_predefineattributevalue_id_seq', 1, false);


--
-- Name: catalog_product_attributes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_product_attributes_id_seq', 1, false);


--
-- Name: catalog_product_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_product_categories_id_seq', 1, false);


--
-- Name: catalog_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_product_id_seq', 1, false);


--
-- Name: catalog_productattribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_productattribute_id_seq', 1, false);


--
-- Name: catalog_productbundle_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_productbundle_categories_id_seq', 1, false);


--
-- Name: catalog_productbundle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_productbundle_id_seq', 1, false);


--
-- Name: catalog_productbundle_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_productbundle_products_id_seq', 1, false);


--
-- Name: discussions_conversation_allowed_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discussions_conversation_allowed_members_id_seq', 1, false);


--
-- Name: discussions_conversation_blacklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discussions_conversation_blacklist_id_seq', 1, false);


--
-- Name: discussions_conversation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discussions_conversation_id_seq', 1, false);


--
-- Name: discussions_discussion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discussions_discussion_id_seq', 3, true);


--
-- Name: discussions_reply_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discussions_reply_id_seq', 1, false);


--
-- Name: discussions_topic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discussions_topic_id_seq', 2, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 77, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 27, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 30, true);


--
-- Name: django_summernote_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_summernote_attachment_id_seq', 1, false);


--
-- Name: events_event_attendees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.events_event_attendees_id_seq', 2, true);


--
-- Name: events_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.events_event_id_seq', 3, true);


--
-- Name: events_invitation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.events_invitation_id_seq', 3, true);


--
-- Name: photos_album_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.photos_album_id_seq', 1, false);


--
-- Name: photos_photo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.photos_photo_id_seq', 1, false);


--
-- Name: shop_basket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shop_basket_id_seq', 1, false);


--
-- Name: shop_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shop_order_id_seq', 1, false);


--
-- Name: shop_orderitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shop_orderitem_id_seq', 1, false);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 13, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: accounts_member accounts_member_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_member
    ADD CONSTRAINT accounts_member_pkey PRIMARY KEY (id);


--
-- Name: accounts_member accounts_member_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_member
    ADD CONSTRAINT accounts_member_slug_key UNIQUE (slug);


--
-- Name: accounts_member accounts_member_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_member
    ADD CONSTRAINT accounts_member_user_id_key UNIQUE (user_id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: campaigns_campaign campaigns_campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_campaign
    ADD CONSTRAINT campaigns_campaign_pkey PRIMARY KEY (id);


--
-- Name: campaigns_campaign campaigns_campaign_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_campaign
    ADD CONSTRAINT campaigns_campaign_slug_key UNIQUE (slug);


--
-- Name: campaigns_cause campaigns_cause_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_cause
    ADD CONSTRAINT campaigns_cause_name_key UNIQUE (name);


--
-- Name: campaigns_cause campaigns_cause_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_cause
    ADD CONSTRAINT campaigns_cause_pkey PRIMARY KEY (id);


--
-- Name: campaigns_cause campaigns_cause_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_cause
    ADD CONSTRAINT campaigns_cause_slug_key UNIQUE (slug);


--
-- Name: campaigns_cause_supporters campaigns_cause_supporters_cause_id_member_id_601e1440_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_cause_supporters
    ADD CONSTRAINT campaigns_cause_supporters_cause_id_member_id_601e1440_uniq UNIQUE (cause_id, member_id);


--
-- Name: campaigns_cause_supporters campaigns_cause_supporters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_cause_supporters
    ADD CONSTRAINT campaigns_cause_supporters_pkey PRIMARY KEY (id);


--
-- Name: campaigns_volunteer campaigns_volunteer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_volunteer
    ADD CONSTRAINT campaigns_volunteer_pkey PRIMARY KEY (id);


--
-- Name: campaigns_volunteer campaigns_volunteer_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_volunteer
    ADD CONSTRAINT campaigns_volunteer_slug_key UNIQUE (slug);


--
-- Name: catalog_category catalog_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_category
    ADD CONSTRAINT catalog_category_pkey PRIMARY KEY (id);


--
-- Name: catalog_category catalog_category_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_category
    ADD CONSTRAINT catalog_category_slug_key UNIQUE (slug);


--
-- Name: catalog_predefineattributevalue catalog_predefineattributevalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_predefineattributevalue
    ADD CONSTRAINT catalog_predefineattributevalue_pkey PRIMARY KEY (id);


--
-- Name: catalog_predefineattributevalue catalog_predefineattributevalue_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_predefineattributevalue
    ADD CONSTRAINT catalog_predefineattributevalue_slug_key UNIQUE (slug);


--
-- Name: catalog_product catalog_product_album_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product
    ADD CONSTRAINT catalog_product_album_id_key UNIQUE (album_id);


--
-- Name: catalog_product_attributes catalog_product_attribut_product_id_predefineattr_d817d943_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product_attributes
    ADD CONSTRAINT catalog_product_attribut_product_id_predefineattr_d817d943_uniq UNIQUE (product_id, predefineattributevalue_id);


--
-- Name: catalog_product_attributes catalog_product_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product_attributes
    ADD CONSTRAINT catalog_product_attributes_pkey PRIMARY KEY (id);


--
-- Name: catalog_product_categories catalog_product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product_categories
    ADD CONSTRAINT catalog_product_categories_pkey PRIMARY KEY (id);


--
-- Name: catalog_product_categories catalog_product_categories_product_id_category_id_9802d7aa_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product_categories
    ADD CONSTRAINT catalog_product_categories_product_id_category_id_9802d7aa_uniq UNIQUE (product_id, category_id);


--
-- Name: catalog_product catalog_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product
    ADD CONSTRAINT catalog_product_pkey PRIMARY KEY (id);


--
-- Name: catalog_product catalog_product_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product
    ADD CONSTRAINT catalog_product_slug_key UNIQUE (slug);


--
-- Name: catalog_productattribute catalog_productattribute_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productattribute
    ADD CONSTRAINT catalog_productattribute_pkey PRIMARY KEY (id);


--
-- Name: catalog_productattribute catalog_productattribute_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productattribute
    ADD CONSTRAINT catalog_productattribute_slug_key UNIQUE (slug);


--
-- Name: catalog_productbundle catalog_productbundle_album_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle
    ADD CONSTRAINT catalog_productbundle_album_id_key UNIQUE (album_id);


--
-- Name: catalog_productbundle_categories catalog_productbundle_ca_productbundle_id_categor_48027f81_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle_categories
    ADD CONSTRAINT catalog_productbundle_ca_productbundle_id_categor_48027f81_uniq UNIQUE (productbundle_id, category_id);


--
-- Name: catalog_productbundle_categories catalog_productbundle_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle_categories
    ADD CONSTRAINT catalog_productbundle_categories_pkey PRIMARY KEY (id);


--
-- Name: catalog_productbundle catalog_productbundle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle
    ADD CONSTRAINT catalog_productbundle_pkey PRIMARY KEY (id);


--
-- Name: catalog_productbundle_products catalog_productbundle_pr_productbundle_id_product_0182afe3_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle_products
    ADD CONSTRAINT catalog_productbundle_pr_productbundle_id_product_0182afe3_uniq UNIQUE (productbundle_id, product_id);


--
-- Name: catalog_productbundle_products catalog_productbundle_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle_products
    ADD CONSTRAINT catalog_productbundle_products_pkey PRIMARY KEY (id);


--
-- Name: catalog_productbundle catalog_productbundle_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle
    ADD CONSTRAINT catalog_productbundle_slug_key UNIQUE (slug);


--
-- Name: discussions_conversation_allowed_members discussions_conversation_allowed_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation_allowed_members
    ADD CONSTRAINT discussions_conversation_allowed_members_pkey PRIMARY KEY (id);


--
-- Name: discussions_conversation_blacklist discussions_conversation_blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation_blacklist
    ADD CONSTRAINT discussions_conversation_blacklist_pkey PRIMARY KEY (id);


--
-- Name: discussions_conversation_blacklist discussions_conversation_conversation_id_member_i_7f63ef96_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation_blacklist
    ADD CONSTRAINT discussions_conversation_conversation_id_member_i_7f63ef96_uniq UNIQUE (conversation_id, member_id);


--
-- Name: discussions_conversation_allowed_members discussions_conversation_conversation_id_member_i_ce9916c1_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation_allowed_members
    ADD CONSTRAINT discussions_conversation_conversation_id_member_i_ce9916c1_uniq UNIQUE (conversation_id, member_id);


--
-- Name: discussions_conversation discussions_conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation
    ADD CONSTRAINT discussions_conversation_pkey PRIMARY KEY (id);


--
-- Name: discussions_conversation discussions_conversation_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation
    ADD CONSTRAINT discussions_conversation_slug_key UNIQUE (slug);


--
-- Name: discussions_discussion discussions_discussion_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_discussion
    ADD CONSTRAINT discussions_discussion_name_key UNIQUE (name);


--
-- Name: discussions_discussion discussions_discussion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_discussion
    ADD CONSTRAINT discussions_discussion_pkey PRIMARY KEY (id);


--
-- Name: discussions_discussion discussions_discussion_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_discussion
    ADD CONSTRAINT discussions_discussion_slug_key UNIQUE (slug);


--
-- Name: discussions_reply discussions_reply_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_reply
    ADD CONSTRAINT discussions_reply_pkey PRIMARY KEY (id);


--
-- Name: discussions_reply discussions_reply_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_reply
    ADD CONSTRAINT discussions_reply_slug_key UNIQUE (slug);


--
-- Name: discussions_topic discussions_topic_campaign_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_topic
    ADD CONSTRAINT discussions_topic_campaign_id_key UNIQUE (campaign_id);


--
-- Name: discussions_topic discussions_topic_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_topic
    ADD CONSTRAINT discussions_topic_name_key UNIQUE (name);


--
-- Name: discussions_topic discussions_topic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_topic
    ADD CONSTRAINT discussions_topic_pkey PRIMARY KEY (id);


--
-- Name: discussions_topic discussions_topic_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_topic
    ADD CONSTRAINT discussions_topic_slug_key UNIQUE (slug);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_summernote_attachment django_summernote_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_summernote_attachment
    ADD CONSTRAINT django_summernote_attachment_pkey PRIMARY KEY (id);


--
-- Name: events_event_attendees events_event_attendees_event_id_member_id_be39c8b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_event_attendees
    ADD CONSTRAINT events_event_attendees_event_id_member_id_be39c8b0_uniq UNIQUE (event_id, member_id);


--
-- Name: events_event_attendees events_event_attendees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_event_attendees
    ADD CONSTRAINT events_event_attendees_pkey PRIMARY KEY (id);


--
-- Name: events_event events_event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_event
    ADD CONSTRAINT events_event_pkey PRIMARY KEY (id);


--
-- Name: events_event events_event_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_event
    ADD CONSTRAINT events_event_slug_key UNIQUE (slug);


--
-- Name: events_invitation events_invitation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_invitation
    ADD CONSTRAINT events_invitation_pkey PRIMARY KEY (id);


--
-- Name: events_invitation events_invitation_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_invitation
    ADD CONSTRAINT events_invitation_slug_key UNIQUE (slug);


--
-- Name: photos_album photos_album_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.photos_album
    ADD CONSTRAINT photos_album_pkey PRIMARY KEY (id);


--
-- Name: photos_album photos_album_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.photos_album
    ADD CONSTRAINT photos_album_slug_key UNIQUE (slug);


--
-- Name: photos_photo photos_photo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.photos_photo
    ADD CONSTRAINT photos_photo_pkey PRIMARY KEY (id);


--
-- Name: photos_photo photos_photo_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.photos_photo
    ADD CONSTRAINT photos_photo_slug_key UNIQUE (slug);


--
-- Name: shop_basket shop_basket_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_basket
    ADD CONSTRAINT shop_basket_customer_id_key UNIQUE (customer_id);


--
-- Name: shop_basket shop_basket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_basket
    ADD CONSTRAINT shop_basket_pkey PRIMARY KEY (id);


--
-- Name: shop_basket shop_basket_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_basket
    ADD CONSTRAINT shop_basket_slug_key UNIQUE (slug);


--
-- Name: shop_order shop_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_order
    ADD CONSTRAINT shop_order_pkey PRIMARY KEY (id);


--
-- Name: shop_order shop_order_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_order
    ADD CONSTRAINT shop_order_slug_key UNIQUE (slug);


--
-- Name: shop_orderitem shop_orderitem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_orderitem
    ADD CONSTRAINT shop_orderitem_pkey PRIMARY KEY (id);


--
-- Name: shop_orderitem shop_orderitem_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_orderitem
    ADD CONSTRAINT shop_orderitem_slug_key UNIQUE (slug);


--
-- Name: users_user users_user_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_email_key UNIQUE (email);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user users_user_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_slug_key UNIQUE (slug);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: accounts_member_slug_1e191966_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_member_slug_1e191966_like ON public.accounts_member USING btree (slug varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: campaigns_campaign_cause_id_5e206520; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX campaigns_campaign_cause_id_5e206520 ON public.campaigns_campaign USING btree (cause_id);


--
-- Name: campaigns_campaign_initiator_id_16baac56; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX campaigns_campaign_initiator_id_16baac56 ON public.campaigns_campaign USING btree (initiator_id);


--
-- Name: campaigns_campaign_slug_08eb9673_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX campaigns_campaign_slug_08eb9673_like ON public.campaigns_campaign USING btree (slug varchar_pattern_ops);


--
-- Name: campaigns_cause_name_a9ebf640_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX campaigns_cause_name_a9ebf640_like ON public.campaigns_cause USING btree (name varchar_pattern_ops);


--
-- Name: campaigns_cause_slug_188eaed8_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX campaigns_cause_slug_188eaed8_like ON public.campaigns_cause USING btree (slug varchar_pattern_ops);


--
-- Name: campaigns_cause_supporters_cause_id_97af3d22; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX campaigns_cause_supporters_cause_id_97af3d22 ON public.campaigns_cause_supporters USING btree (cause_id);


--
-- Name: campaigns_cause_supporters_member_id_1d812d91; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX campaigns_cause_supporters_member_id_1d812d91 ON public.campaigns_cause_supporters USING btree (member_id);


--
-- Name: campaigns_volunteer_campaign_id_f3cd98f8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX campaigns_volunteer_campaign_id_f3cd98f8 ON public.campaigns_volunteer USING btree (campaign_id);


--
-- Name: campaigns_volunteer_member_id_a5d649a9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX campaigns_volunteer_member_id_a5d649a9 ON public.campaigns_volunteer USING btree (member_id);


--
-- Name: campaigns_volunteer_slug_337d8835_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX campaigns_volunteer_slug_337d8835_like ON public.campaigns_volunteer USING btree (slug varchar_pattern_ops);


--
-- Name: catalog_category_parent_id_f61bd017; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_category_parent_id_f61bd017 ON public.catalog_category USING btree (parent_id);


--
-- Name: catalog_category_slug_dbf63ad0_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_category_slug_dbf63ad0_like ON public.catalog_category USING btree (slug varchar_pattern_ops);


--
-- Name: catalog_predefineattributevalue_attribute_id_a7c381ce; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_predefineattributevalue_attribute_id_a7c381ce ON public.catalog_predefineattributevalue USING btree (attribute_id);


--
-- Name: catalog_predefineattributevalue_slug_e376d566_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_predefineattributevalue_slug_e376d566_like ON public.catalog_predefineattributevalue USING btree (slug varchar_pattern_ops);


--
-- Name: catalog_product_attributes_predefineattributevalue_id_cb2fd373; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_product_attributes_predefineattributevalue_id_cb2fd373 ON public.catalog_product_attributes USING btree (predefineattributevalue_id);


--
-- Name: catalog_product_attributes_product_id_fa7721a7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_product_attributes_product_id_fa7721a7 ON public.catalog_product_attributes USING btree (product_id);


--
-- Name: catalog_product_categories_category_id_f9457ae1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_product_categories_category_id_f9457ae1 ON public.catalog_product_categories USING btree (category_id);


--
-- Name: catalog_product_categories_product_id_be67c3f5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_product_categories_product_id_be67c3f5 ON public.catalog_product_categories USING btree (product_id);


--
-- Name: catalog_product_parent_id_a23e011c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_product_parent_id_a23e011c ON public.catalog_product USING btree (parent_id);


--
-- Name: catalog_product_slug_f37848b0_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_product_slug_f37848b0_like ON public.catalog_product USING btree (slug varchar_pattern_ops);


--
-- Name: catalog_product_vendor_id_b705400c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_product_vendor_id_b705400c ON public.catalog_product USING btree (vendor_id);


--
-- Name: catalog_productattribute_slug_7a29bcb7_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_productattribute_slug_7a29bcb7_like ON public.catalog_productattribute USING btree (slug varchar_pattern_ops);


--
-- Name: catalog_productbundle_categories_category_id_8b52efdd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_productbundle_categories_category_id_8b52efdd ON public.catalog_productbundle_categories USING btree (category_id);


--
-- Name: catalog_productbundle_categories_productbundle_id_22baf149; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_productbundle_categories_productbundle_id_22baf149 ON public.catalog_productbundle_categories USING btree (productbundle_id);


--
-- Name: catalog_productbundle_products_product_id_655f493d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_productbundle_products_product_id_655f493d ON public.catalog_productbundle_products USING btree (product_id);


--
-- Name: catalog_productbundle_products_productbundle_id_7c5a30cd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_productbundle_products_productbundle_id_7c5a30cd ON public.catalog_productbundle_products USING btree (productbundle_id);


--
-- Name: catalog_productbundle_slug_8388f5bd_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_productbundle_slug_8388f5bd_like ON public.catalog_productbundle USING btree (slug varchar_pattern_ops);


--
-- Name: catalog_productbundle_vendor_id_0bce219b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX catalog_productbundle_vendor_id_0bce219b ON public.catalog_productbundle USING btree (vendor_id);


--
-- Name: discussions_conversation_a_conversation_id_c8a30068; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_conversation_a_conversation_id_c8a30068 ON public.discussions_conversation_allowed_members USING btree (conversation_id);


--
-- Name: discussions_conversation_allowed_members_member_id_4e89271a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_conversation_allowed_members_member_id_4e89271a ON public.discussions_conversation_allowed_members USING btree (member_id);


--
-- Name: discussions_conversation_author_id_dfaf9701; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_conversation_author_id_dfaf9701 ON public.discussions_conversation USING btree (author_id);


--
-- Name: discussions_conversation_blacklist_conversation_id_455e4712; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_conversation_blacklist_conversation_id_455e4712 ON public.discussions_conversation_blacklist USING btree (conversation_id);


--
-- Name: discussions_conversation_blacklist_member_id_95927660; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_conversation_blacklist_member_id_95927660 ON public.discussions_conversation_blacklist USING btree (member_id);


--
-- Name: discussions_conversation_slug_471482dc_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_conversation_slug_471482dc_like ON public.discussions_conversation USING btree (slug varchar_pattern_ops);


--
-- Name: discussions_conversation_topic_id_da79fdc2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_conversation_topic_id_da79fdc2 ON public.discussions_conversation USING btree (topic_id);


--
-- Name: discussions_discussion_name_a866b952_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_discussion_name_a866b952_like ON public.discussions_discussion USING btree (name varchar_pattern_ops);


--
-- Name: discussions_discussion_slug_32a5f4fa_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_discussion_slug_32a5f4fa_like ON public.discussions_discussion USING btree (slug varchar_pattern_ops);


--
-- Name: discussions_reply_author_id_d429f2d1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_reply_author_id_d429f2d1 ON public.discussions_reply USING btree (author_id);


--
-- Name: discussions_reply_conversation_id_ba45fa13; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_reply_conversation_id_ba45fa13 ON public.discussions_reply USING btree (conversation_id);


--
-- Name: discussions_reply_parent_id_216a356a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_reply_parent_id_216a356a ON public.discussions_reply USING btree (parent_id);


--
-- Name: discussions_reply_slug_acf70300_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_reply_slug_acf70300_like ON public.discussions_reply USING btree (slug varchar_pattern_ops);


--
-- Name: discussions_topic_discussion_id_dce9b730; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_topic_discussion_id_dce9b730 ON public.discussions_topic USING btree (discussion_id);


--
-- Name: discussions_topic_name_d3e47abd_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_topic_name_d3e47abd_like ON public.discussions_topic USING btree (name varchar_pattern_ops);


--
-- Name: discussions_topic_slug_f84dc89d_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX discussions_topic_slug_f84dc89d_like ON public.discussions_topic USING btree (slug varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: events_event_attendees_event_id_45694efb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_event_attendees_event_id_45694efb ON public.events_event_attendees USING btree (event_id);


--
-- Name: events_event_attendees_member_id_ec4b8d4d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_event_attendees_member_id_ec4b8d4d ON public.events_event_attendees USING btree (member_id);


--
-- Name: events_event_creator_id_13bb3d46; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_event_creator_id_13bb3d46 ON public.events_event USING btree (creator_id);


--
-- Name: events_event_slug_b44b2c04_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_event_slug_b44b2c04_like ON public.events_event USING btree (slug varchar_pattern_ops);


--
-- Name: events_invitation_attendee_id_5680e58a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_invitation_attendee_id_5680e58a ON public.events_invitation USING btree (attendee_id);


--
-- Name: events_invitation_event_id_24713f00; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_invitation_event_id_24713f00 ON public.events_invitation USING btree (event_id);


--
-- Name: events_invitation_slug_946a1965_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_invitation_slug_946a1965_like ON public.events_invitation USING btree (slug varchar_pattern_ops);


--
-- Name: photos_album_owner_id_2eb5c2d7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX photos_album_owner_id_2eb5c2d7 ON public.photos_album USING btree (owner_id);


--
-- Name: photos_album_slug_de6fbed1_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX photos_album_slug_de6fbed1_like ON public.photos_album USING btree (slug varchar_pattern_ops);


--
-- Name: photos_photo_album_id_d37b4f12; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX photos_photo_album_id_d37b4f12 ON public.photos_photo USING btree (album_id);


--
-- Name: photos_photo_slug_d951358b_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX photos_photo_slug_d951358b_like ON public.photos_photo USING btree (slug varchar_pattern_ops);


--
-- Name: shop_basket_slug_a90ae202_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shop_basket_slug_a90ae202_like ON public.shop_basket USING btree (slug varchar_pattern_ops);


--
-- Name: shop_order_customer_id_f638df20; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shop_order_customer_id_f638df20 ON public.shop_order USING btree (customer_id);


--
-- Name: shop_order_slug_2bd54d6f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shop_order_slug_2bd54d6f_like ON public.shop_order USING btree (slug varchar_pattern_ops);


--
-- Name: shop_orderitem_basket_id_16fdc488; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shop_orderitem_basket_id_16fdc488 ON public.shop_orderitem USING btree (basket_id);


--
-- Name: shop_orderitem_order_id_2f1b00cf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shop_orderitem_order_id_2f1b00cf ON public.shop_orderitem USING btree (order_id);


--
-- Name: shop_orderitem_product_id_48153f22; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shop_orderitem_product_id_48153f22 ON public.shop_orderitem USING btree (product_id);


--
-- Name: shop_orderitem_slug_d40b5d1c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shop_orderitem_slug_d40b5d1c_like ON public.shop_orderitem USING btree (slug varchar_pattern_ops);


--
-- Name: shop_orderitem_vendor_id_f6e89d73; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shop_orderitem_vendor_id_f6e89d73 ON public.shop_orderitem USING btree (vendor_id);


--
-- Name: users_user_email_243f6e77_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_email_243f6e77_like ON public.users_user USING btree (email varchar_pattern_ops);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_slug_5176bea7_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_slug_5176bea7_like ON public.users_user USING btree (slug varchar_pattern_ops);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: accounts_member accounts_member_user_id_b994c8b6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_member
    ADD CONSTRAINT accounts_member_user_id_b994c8b6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: campaigns_campaign campaigns_campaign_cause_id_5e206520_fk_campaigns_cause_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_campaign
    ADD CONSTRAINT campaigns_campaign_cause_id_5e206520_fk_campaigns_cause_id FOREIGN KEY (cause_id) REFERENCES public.campaigns_cause(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: campaigns_campaign campaigns_campaign_initiator_id_16baac56_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_campaign
    ADD CONSTRAINT campaigns_campaign_initiator_id_16baac56_fk_accounts_member_id FOREIGN KEY (initiator_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: campaigns_cause_supporters campaigns_cause_supp_cause_id_97af3d22_fk_campaigns; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_cause_supporters
    ADD CONSTRAINT campaigns_cause_supp_cause_id_97af3d22_fk_campaigns FOREIGN KEY (cause_id) REFERENCES public.campaigns_cause(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: campaigns_cause_supporters campaigns_cause_supp_member_id_1d812d91_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_cause_supporters
    ADD CONSTRAINT campaigns_cause_supp_member_id_1d812d91_fk_accounts_ FOREIGN KEY (member_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: campaigns_volunteer campaigns_volunteer_campaign_id_f3cd98f8_fk_campaigns; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_volunteer
    ADD CONSTRAINT campaigns_volunteer_campaign_id_f3cd98f8_fk_campaigns FOREIGN KEY (campaign_id) REFERENCES public.campaigns_campaign(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: campaigns_volunteer campaigns_volunteer_member_id_a5d649a9_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns_volunteer
    ADD CONSTRAINT campaigns_volunteer_member_id_a5d649a9_fk_accounts_member_id FOREIGN KEY (member_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_category catalog_category_parent_id_f61bd017_fk_catalog_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_category
    ADD CONSTRAINT catalog_category_parent_id_f61bd017_fk_catalog_category_id FOREIGN KEY (parent_id) REFERENCES public.catalog_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_predefineattributevalue catalog_predefineatt_attribute_id_a7c381ce_fk_catalog_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_predefineattributevalue
    ADD CONSTRAINT catalog_predefineatt_attribute_id_a7c381ce_fk_catalog_p FOREIGN KEY (attribute_id) REFERENCES public.catalog_productattribute(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_product catalog_product_album_id_40a4bcde_fk_photos_album_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product
    ADD CONSTRAINT catalog_product_album_id_40a4bcde_fk_photos_album_id FOREIGN KEY (album_id) REFERENCES public.photos_album(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_product_attributes catalog_product_attr_predefineattributeva_cb2fd373_fk_catalog_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product_attributes
    ADD CONSTRAINT catalog_product_attr_predefineattributeva_cb2fd373_fk_catalog_p FOREIGN KEY (predefineattributevalue_id) REFERENCES public.catalog_predefineattributevalue(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_product_attributes catalog_product_attr_product_id_fa7721a7_fk_catalog_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product_attributes
    ADD CONSTRAINT catalog_product_attr_product_id_fa7721a7_fk_catalog_p FOREIGN KEY (product_id) REFERENCES public.catalog_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_product_categories catalog_product_cate_category_id_f9457ae1_fk_catalog_c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product_categories
    ADD CONSTRAINT catalog_product_cate_category_id_f9457ae1_fk_catalog_c FOREIGN KEY (category_id) REFERENCES public.catalog_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_product_categories catalog_product_cate_product_id_be67c3f5_fk_catalog_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product_categories
    ADD CONSTRAINT catalog_product_cate_product_id_be67c3f5_fk_catalog_p FOREIGN KEY (product_id) REFERENCES public.catalog_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_product catalog_product_parent_id_a23e011c_fk_catalog_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product
    ADD CONSTRAINT catalog_product_parent_id_a23e011c_fk_catalog_product_id FOREIGN KEY (parent_id) REFERENCES public.catalog_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_product catalog_product_vendor_id_b705400c_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_product
    ADD CONSTRAINT catalog_product_vendor_id_b705400c_fk_accounts_member_id FOREIGN KEY (vendor_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_productbundle_categories catalog_productbundl_category_id_8b52efdd_fk_catalog_c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle_categories
    ADD CONSTRAINT catalog_productbundl_category_id_8b52efdd_fk_catalog_c FOREIGN KEY (category_id) REFERENCES public.catalog_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_productbundle_products catalog_productbundl_product_id_655f493d_fk_catalog_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle_products
    ADD CONSTRAINT catalog_productbundl_product_id_655f493d_fk_catalog_p FOREIGN KEY (product_id) REFERENCES public.catalog_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_productbundle_categories catalog_productbundl_productbundle_id_22baf149_fk_catalog_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle_categories
    ADD CONSTRAINT catalog_productbundl_productbundle_id_22baf149_fk_catalog_p FOREIGN KEY (productbundle_id) REFERENCES public.catalog_productbundle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_productbundle_products catalog_productbundl_productbundle_id_7c5a30cd_fk_catalog_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle_products
    ADD CONSTRAINT catalog_productbundl_productbundle_id_7c5a30cd_fk_catalog_p FOREIGN KEY (productbundle_id) REFERENCES public.catalog_productbundle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_productbundle catalog_productbundle_album_id_30996624_fk_photos_album_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle
    ADD CONSTRAINT catalog_productbundle_album_id_30996624_fk_photos_album_id FOREIGN KEY (album_id) REFERENCES public.photos_album(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: catalog_productbundle catalog_productbundle_vendor_id_0bce219b_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_productbundle
    ADD CONSTRAINT catalog_productbundle_vendor_id_0bce219b_fk_accounts_member_id FOREIGN KEY (vendor_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussions_conversation discussions_conversa_author_id_dfaf9701_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation
    ADD CONSTRAINT discussions_conversa_author_id_dfaf9701_fk_accounts_ FOREIGN KEY (author_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussions_conversation_blacklist discussions_conversa_conversation_id_455e4712_fk_discussio; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation_blacklist
    ADD CONSTRAINT discussions_conversa_conversation_id_455e4712_fk_discussio FOREIGN KEY (conversation_id) REFERENCES public.discussions_conversation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussions_conversation_allowed_members discussions_conversa_conversation_id_c8a30068_fk_discussio; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation_allowed_members
    ADD CONSTRAINT discussions_conversa_conversation_id_c8a30068_fk_discussio FOREIGN KEY (conversation_id) REFERENCES public.discussions_conversation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussions_conversation_allowed_members discussions_conversa_member_id_4e89271a_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation_allowed_members
    ADD CONSTRAINT discussions_conversa_member_id_4e89271a_fk_accounts_ FOREIGN KEY (member_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussions_conversation_blacklist discussions_conversa_member_id_95927660_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation_blacklist
    ADD CONSTRAINT discussions_conversa_member_id_95927660_fk_accounts_ FOREIGN KEY (member_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussions_conversation discussions_conversa_topic_id_da79fdc2_fk_discussio; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_conversation
    ADD CONSTRAINT discussions_conversa_topic_id_da79fdc2_fk_discussio FOREIGN KEY (topic_id) REFERENCES public.discussions_topic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussions_reply discussions_reply_author_id_d429f2d1_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_reply
    ADD CONSTRAINT discussions_reply_author_id_d429f2d1_fk_accounts_member_id FOREIGN KEY (author_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussions_reply discussions_reply_conversation_id_ba45fa13_fk_discussio; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_reply
    ADD CONSTRAINT discussions_reply_conversation_id_ba45fa13_fk_discussio FOREIGN KEY (conversation_id) REFERENCES public.discussions_conversation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussions_reply discussions_reply_parent_id_216a356a_fk_discussions_reply_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_reply
    ADD CONSTRAINT discussions_reply_parent_id_216a356a_fk_discussions_reply_id FOREIGN KEY (parent_id) REFERENCES public.discussions_reply(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussions_topic discussions_topic_campaign_id_92f2e2a5_fk_campaigns_campaign_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_topic
    ADD CONSTRAINT discussions_topic_campaign_id_92f2e2a5_fk_campaigns_campaign_id FOREIGN KEY (campaign_id) REFERENCES public.campaigns_campaign(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: discussions_topic discussions_topic_discussion_id_dce9b730_fk_discussio; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discussions_topic
    ADD CONSTRAINT discussions_topic_discussion_id_dce9b730_fk_discussio FOREIGN KEY (discussion_id) REFERENCES public.discussions_discussion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: events_event_attendees events_event_attendees_event_id_45694efb_fk_events_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_event_attendees
    ADD CONSTRAINT events_event_attendees_event_id_45694efb_fk_events_event_id FOREIGN KEY (event_id) REFERENCES public.events_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: events_event_attendees events_event_attendees_member_id_ec4b8d4d_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_event_attendees
    ADD CONSTRAINT events_event_attendees_member_id_ec4b8d4d_fk_accounts_member_id FOREIGN KEY (member_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: events_event events_event_creator_id_13bb3d46_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_event
    ADD CONSTRAINT events_event_creator_id_13bb3d46_fk_accounts_member_id FOREIGN KEY (creator_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: events_invitation events_invitation_attendee_id_5680e58a_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_invitation
    ADD CONSTRAINT events_invitation_attendee_id_5680e58a_fk_accounts_member_id FOREIGN KEY (attendee_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: events_invitation events_invitation_event_id_24713f00_fk_events_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events_invitation
    ADD CONSTRAINT events_invitation_event_id_24713f00_fk_events_event_id FOREIGN KEY (event_id) REFERENCES public.events_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: photos_album photos_album_owner_id_2eb5c2d7_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.photos_album
    ADD CONSTRAINT photos_album_owner_id_2eb5c2d7_fk_users_user_id FOREIGN KEY (owner_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: photos_photo photos_photo_album_id_d37b4f12_fk_photos_album_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.photos_photo
    ADD CONSTRAINT photos_photo_album_id_d37b4f12_fk_photos_album_id FOREIGN KEY (album_id) REFERENCES public.photos_album(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop_basket shop_basket_customer_id_68393757_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_basket
    ADD CONSTRAINT shop_basket_customer_id_68393757_fk_accounts_member_id FOREIGN KEY (customer_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop_order shop_order_customer_id_f638df20_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_order
    ADD CONSTRAINT shop_order_customer_id_f638df20_fk_accounts_member_id FOREIGN KEY (customer_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop_orderitem shop_orderitem_basket_id_16fdc488_fk_shop_basket_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_orderitem
    ADD CONSTRAINT shop_orderitem_basket_id_16fdc488_fk_shop_basket_id FOREIGN KEY (basket_id) REFERENCES public.shop_basket(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop_orderitem shop_orderitem_order_id_2f1b00cf_fk_shop_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_orderitem
    ADD CONSTRAINT shop_orderitem_order_id_2f1b00cf_fk_shop_order_id FOREIGN KEY (order_id) REFERENCES public.shop_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop_orderitem shop_orderitem_product_id_48153f22_fk_catalog_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_orderitem
    ADD CONSTRAINT shop_orderitem_product_id_48153f22_fk_catalog_product_id FOREIGN KEY (product_id) REFERENCES public.catalog_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shop_orderitem shop_orderitem_vendor_id_f6e89d73_fk_accounts_member_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_orderitem
    ADD CONSTRAINT shop_orderitem_vendor_id_f6e89d73_fk_accounts_member_id FOREIGN KEY (vendor_id) REFERENCES public.accounts_member(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

